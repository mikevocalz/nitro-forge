package com.margelo.nitro.video

import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.annotation.MainThread
import androidx.media3.common.C
import androidx.media3.common.Metadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.text.CueGroup
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.upstream.DefaultAllocator
import androidx.media3.extractor.metadata.emsg.EventMessage
import androidx.media3.extractor.metadata.id3.Id3Frame
import androidx.media3.extractor.metadata.id3.TextInformationFrame
import androidx.media3.ui.PlayerView
import com.facebook.proguard.annotations.DoNotStrip
import com.margelo.nitro.NitroModules
import com.margelo.nitro.core.Promise
import com.twg.video.core.LibraryError
import com.twg.video.core.PlayerError
import com.twg.video.core.VideoManager
import com.twg.video.core.extensions.updateService
import com.twg.video.core.player.OnAudioFocusChangedListener
import com.twg.video.core.recivers.AudioBecomingNoisyReceiver
import com.twg.video.core.services.playback.VideoPlaybackService
import com.twg.video.core.services.playback.VideoPlaybackServiceConnection
import com.twg.video.core.utils.TextTrackUtils
import com.twg.video.core.utils.Threading.runOnMainThread
import com.twg.video.core.utils.VideoOrientationUtils
import com.twg.video.view.VideoView
import java.lang.ref.WeakReference
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel

internal fun Player.setPlaybackRate(rate: Double) {
  if (rate <= 0.0) {
    pause()
    return
  }

  playbackParameters = playbackParameters.withSpeed(rate.toFloat())
}

@UnstableApi
@DoNotStrip
class HybridVideoPlayer() : HybridVideoPlayerSpec(), AutoCloseable {
  override lateinit var source: HybridVideoPlayerSourceSpec
  override var eventEmitter = HybridVideoPlayerEventEmitter()
    set(value) {
      if (field != value) {
        audioFocusChangedListener.setEventEmitter(value)
        audioBecomingNoisyReceiver.setEventEmitter(value)
      }
      field = value
    }

  private var allocator: DefaultAllocator? = null
  private var context = NitroModules.applicationContext
    ?: run {
    throw LibraryError.ApplicationContextNotFound
  }

  lateinit var player: ExoPlayer
    private set
  private val ownerScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
  private val ownerReady = CompletableDeferred<Unit>()
  internal suspend fun awaitOwner() { ownerReady.await(); ensureNotReleased() }

  private data class Snapshot(
    val currentTime: Double = 0.0, val volume: Double = 1.0, val duration: Double = Double.NaN,
    val loop: Boolean = false, val muted: Boolean = false, val rate: Double = 1.0,
    val isPlaying: Boolean = false, val tracks: Array<TextTrack> = emptyArray(), val selected: TextTrack? = null
  )
  @Volatile private var snapshot = Snapshot()
  private fun refreshSnapshot() {
    if (!::player.isInitialized || releaseStarted.get()) return
    snapshot = Snapshot(player.currentPosition / 1000.0, player.volume.toDouble(),
      if (player.duration == C.TIME_UNSET) Double.NaN else player.duration / 1000.0,
      player.repeatMode == Player.REPEAT_MODE_ONE, player.volume == 0f,
      player.playbackParameters.speed.toDouble(), player.isPlaying,
      if (::source.isInitialized) TextTrackUtils.getAvailableTextTracks(player, source) else emptyArray(),
      if (::source.isInitialized) TextTrackUtils.getSelectedTrack(player, source) else null)
  }

  private fun onOwner(action: () -> Unit) {
    check(Looper.myLooper() == Looper.getMainLooper()) { "Native player mutation requires its owner" }
    ensureNotReleased()
    action()
    refreshSnapshot()
  }

  var loadedWithSource = false
  private val releaseStarted = AtomicBoolean(false)
  internal val isReleaseStarted: Boolean
    get() = releaseStarted.get()
  private var currentPlayerView: WeakReference<PlayerView>? = null

  var wasAutoPaused = false

  // Buffer Config
  private var bufferConfig: BufferConfig? = null
    get() = source.config.bufferConfig

  // Time updates
  private val progressHandler = Handler(Looper.getMainLooper())
  private var progressRunnable: Runnable? = null

  // Listeners
  private val audioFocusChangedListener = OnAudioFocusChangedListener()
  private val audioBecomingNoisyReceiver = AudioBecomingNoisyReceiver()

  // Service Connection
  private val videoPlaybackServiceConnection = VideoPlaybackServiceConnection(WeakReference(this), context)

  // Text track selection state
  private var selectedExternalTrackIndex: Int? = null

  companion object : HybridVideoPlayerSpec.Companion {
    const val PROGRESS_UPDATE_INTERVAL_MS = 250L
    private const val TAG = "HybridVideoPlayer"
    private const val DEFAULT_MIN_BUFFER_DURATION_MS = 5000
    private const val DEFAULT_MAX_BUFFER_DURATION_MS = 10000
    private const val DEFAULT_BUFFER_FOR_PLAYBACK_DURATION_MS = 1000
    private const val DEFAULT_BUFFER_FOR_PLAYBACK_AFTER_REBUFFER_DURATION_MS = 2000
    private const val DEFAULT_BACK_BUFFER_DURATION_MS = 0
  }

  @Volatile override var status: VideoPlayerStatus = VideoPlayerStatus.IDLE
    set(value) {
      if (field != value) {
        eventEmitter.onStatusChange(value)
      }
      field = value
    }

  @Volatile override var showNotificationControls: Boolean = false
    set(value) { onOwner { field = value; VideoPlaybackService.updateService(videoPlaybackServiceConnection) } }
  override var currentTime: Double
    get() = snapshot.currentTime
    set(value) { onOwner { player.seekTo((value * 1000).toLong()) } }
  var userVolume: Double = 1.0
  override var volume: Double
    get() = snapshot.volume
    set(value) { onOwner { userVolume = value; player.volume = value.toFloat() } }
  override val duration: Double get() = snapshot.duration
  override var loop: Boolean
    get() = snapshot.loop
    set(value) { onOwner { player.repeatMode = if (value) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF } }
  override var muted: Boolean
    get() = snapshot.muted
    set(value) { onOwner {
      player.volume = if (value) 0f else userVolume.toFloat()
      eventEmitter.onVolumeChange(onVolumeChangeData(player.volume.toDouble(), value))
    } }
  override var rate: Double
    get() = snapshot.rate
    set(value) { onOwner { player.setPlaybackRate(value) } }
  @Volatile override var mixAudioMode: MixAudioMode = MixAudioMode.AUTO
    set(value) { onOwner { field = value; VideoManager.audioFocusManager.requestAudioFocusUpdate() } }
  @Volatile override var ignoreSilentSwitchMode: IgnoreSilentSwitchMode = IgnoreSilentSwitchMode.AUTO
  @Volatile override var disableAudioSessionManagement: Boolean = false
  @Volatile override var playInBackground: Boolean = false
    set(value) { onOwner { field = value; VideoPlaybackService.updateService(videoPlaybackServiceConnection) } }
  @Volatile override var playWhenInactive: Boolean = false
  override val isPlaying: Boolean get() = snapshot.isPlaying

  override fun configure(options: NativePlayerOptions): Promise<Unit> = Promise.async(ownerScope) {
    awaitOwner()
    options.volume?.let { require(it.isFinite() && it in 0.0..1.0) { "Volume must be in 0...1" } }
    options.rate?.let { require(it.isFinite() && it >= 0) { "Rate must be finite and nonnegative" } }
    options.showNotificationControls?.let { showNotificationControls = it }
    options.volume?.let { volume = it }
    options.muted?.let { muted = it }
    options.loop?.let { loop = it }
    options.rate?.let { rate = it }
    options.mixAudioMode?.let { mixAudioMode = it }
    options.ignoreSilentSwitchMode?.let { ignoreSilentSwitchMode = it }
    options.playInBackground?.let { playInBackground = it }
    options.playWhenInactive?.let { playWhenInactive = it }
    options.disableAudioSessionManagement?.let { disableAudioSessionManagement = it }
    refreshSnapshot()
  }

  private fun initializePlayer() {
    if (NitroModules.applicationContext == null) {
      throw LibraryError.ApplicationContextNotFound
    }

    val hybridSource = source as? HybridVideoPlayerSource ?: throw PlayerError.InvalidSource

    // Initialize the allocator
    allocator = DefaultAllocator(true, C.DEFAULT_BUFFER_SEGMENT_SIZE)

    // Create a LoadControl with the allocator
    val loadControl = DefaultLoadControl.Builder()
      .setAllocator(allocator!!)
      .setBufferDurationsMs(
        bufferConfig?.minBufferMs?.toInt() ?: DEFAULT_MIN_BUFFER_DURATION_MS, // minBufferMs
        bufferConfig?.maxBufferMs?.toInt() ?: DEFAULT_MAX_BUFFER_DURATION_MS, // maxBufferMs
        bufferConfig?.bufferForPlaybackMs?.toInt()
          ?: DEFAULT_BUFFER_FOR_PLAYBACK_DURATION_MS, // bufferForPlaybackMs
        bufferConfig?.bufferForPlaybackAfterRebufferMs?.toInt()
          ?: DEFAULT_BUFFER_FOR_PLAYBACK_AFTER_REBUFFER_DURATION_MS // bufferForPlaybackAfterRebufferMs
      )
      .setBackBuffer(
        bufferConfig?.backBufferDurationMs?.toInt()
          ?: DEFAULT_BACK_BUFFER_DURATION_MS, // backBufferDurationMs,
        false // retainBackBufferFromKeyframe
      )
      .build()

    val renderersFactory = DefaultRenderersFactory(context)
      .forceEnableMediaCodecAsynchronousQueueing()
      .setEnableDecoderFallback(true)

    // Build the player with the LoadControl
    val retained = snapshot
    val previousPlayer = player
    player = ExoPlayer.Builder(context)
      .setLoadControl(loadControl)
      .setLooper(Looper.getMainLooper())
      .setRenderersFactory(renderersFactory)
      .build()
    player.volume = if (retained.muted) 0f else userVolume.toFloat()
    player.repeatMode = if (retained.loop) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
    player.setPlaybackRate(retained.rate)
    refreshSnapshot()
    // Release the previous player (the placeholder, or an earlier one if initialize() runs again)
    // so it doesn't leak. Remove the listeners first, like completeRelease(), so a release timeout
    // doesn't report an error on this player.
    currentPlayerView?.get()?.player = player
    previousPlayer.removeListener(playerListener)
    previousPlayer.removeAnalyticsListener(analyticsListener)
    previousPlayer.release()

    loadedWithSource = true

    applyVideoQualityConstraints()

    player.addListener(playerListener)
    player.addAnalyticsListener(analyticsListener)
    player.setMediaSource(hybridSource.mediaSource)
    ensureNotReleased()

    // Emit onLoadStart
    val sourceType = if (hybridSource.uri.startsWith("http")) SourceType.NETWORK else SourceType.LOCAL
    eventEmitter.onLoadStart(onLoadStartData(sourceType = sourceType, source = hybridSource))
    ensureNotReleased()
    status = VideoPlayerStatus.LOADING
    ensureNotReleased()
    startProgressUpdates()
  }

  /**
   * Applies `bufferConfig.preferredMaximumResolution` and
   * `preferredPeakBitRate` to the player's track selection.
   *
   * Both options were previously iOS-only in practice: they are applied to the
   * `AVPlayerItem` in `AVPlayerItem+setBufferConfig.swift`, while Android read
   * only the buffering fields off the same config and silently ignored these
   * two. ExoPlayer expresses the same constraints through
   * `TrackSelectionParameters`, which this file's sibling `TextTrackUtils`
   * already uses for text-track selection.
   *
   * Called from `initializePlayer`, which every caller runs inside
   * the native owner — `trackSelectionParameters` must be set on the
   * player's application thread.
   */
  private fun applyVideoQualityConstraints() {
    val config = bufferConfig ?: return
    val maxResolution = config.preferredMaximumResolution
    val maxBitRate = config.preferredPeakBitRate

    if (maxResolution == null && maxBitRate == null) return

    player.trackSelectionParameters = player.trackSelectionParameters
      .buildUpon()
      .apply {
        maxResolution?.let { setMaxVideoSize(it.width.toInt(), it.height.toInt()) }
        maxBitRate?.let { setMaxVideoBitrate(it.toInt()) }
      }
      .build()
  }

  private fun ensureNotReleased() {
    if (releaseStarted.get()) {
      throw PlayerError.Cancelled
    }
  }

  override fun initialize(): Promise<Unit> = Promise.async(ownerScope) {
    awaitOwner()
    if (!loadedWithSource) initializePlayer()
    player.prepare()
    refreshSnapshot()
  }

  constructor(source: HybridVideoPlayerSource) : this() {
    this.source = source
    progressHandler.post {
      try {
        ensureNotReleased()
        player = ExoPlayer.Builder(context).setLooper(Looper.getMainLooper()).build()
        VideoManager.registerPlayer(this)
        ownerReady.complete(Unit)
        if (source.config.initializeOnCreation == true) {
          initializePlayer()
          player.prepare()
        }
      } catch (error: Throwable) {
        ownerReady.completeExceptionally(error)
        eventEmitter.onError(error.message ?: "Native player initialization failed")
      }
    }
  }

  override fun play(): Promise<Unit> = Promise.async(ownerScope) { awaitOwner(); player.play(); refreshSnapshot() }
  override fun pause(): Promise<Unit> = Promise.async(ownerScope) { awaitOwner(); player.pause(); refreshSnapshot() }
  override fun seekBy(time: Double): Promise<Unit> = Promise.async(ownerScope) {
    awaitOwner(); require(time.isFinite()) { "Seek offset must be finite" }
    val end = if (duration.isFinite()) duration else Double.POSITIVE_INFINITY
    currentTime = (player.currentPosition / 1000.0 + time).coerceIn(0.0, end)
  }
  override fun seekTo(time: Double): Promise<Unit> = Promise.async(ownerScope) {
    awaitOwner(); require(time.isFinite() && time >= 0) { "Seek time must be finite and nonnegative" }
    val end = if (duration.isFinite()) duration else Double.POSITIVE_INFINITY
    currentTime = time.coerceIn(0.0, end)
  }

  override fun replaceSourceAsync(source: Variant_HybridVideoPlayerSourceSpec_NullType): Promise<Unit> = Promise.async(ownerScope) {
    awaitOwner()
    val replacement = source.asFirstOrNull()
    if (replacement == null) { release(); return@async }
    val hybrid = replacement as? HybridVideoPlayerSource ?: throw PlayerError.InvalidSource
    (this@HybridVideoPlayer.source as? HybridVideoPlayerSource)?.sourceLoader?.cancel()
    this@HybridVideoPlayer.source = hybrid
    player.pause()
    initializePlayer()
    player.prepare()
    refreshSnapshot()
  }

  override fun preload(): Promise<Unit> = Promise.async(ownerScope) {
    awaitOwner()
    if (!loadedWithSource) initializePlayer()
    if (player.playbackState == Player.STATE_IDLE) player.prepare()
    refreshSnapshot()
  }

  override fun release() {
    if (!releaseStarted.compareAndSet(false, true)) {
      return
    }

    ownerReady.completeExceptionally(PlayerError.Cancelled)
    snapshot = Snapshot()
    eventEmitter.clearAllListeners()
    // Defer teardown until the current main-thread callback chain has finished.
    progressHandler.post { completeRelease() }
  }

  @MainThread
  private fun completeRelease() {
    if (!::player.isInitialized) { ownerScope.cancel(); return }
    VideoPlaybackService.updateService(videoPlaybackServiceConnection)

    try {
      VideoManager.unregisterPlayer(this)
    } finally {
      stopProgressUpdates()
      loadedWithSource = false

      eventEmitter.clearAllListeners()

      player.removeListener(playerListener)
      player.removeAnalyticsListener(analyticsListener)
      player.release() // Release player
      ownerScope.cancel()

      // Clean Listeners
      audioFocusChangedListener.removeEventEmitter()
      audioBecomingNoisyReceiver.removeEventEmitter()

      // Update status
      status = VideoPlayerStatus.IDLE
    }
  }

  fun movePlayerToVideoView(videoView: VideoView) {
    VideoManager.addViewToPlayer(videoView, this)

    check(Looper.myLooper() == Looper.getMainLooper())
    PlayerView.switchTargetView(player, currentPlayerView?.get(), videoView.playerView)
    currentPlayerView = WeakReference(videoView.playerView)
  }

  override fun dispose() {
    release()
    super.dispose()
  }

  override fun close() {
    release()
  }

  override val memorySize: Long
    // 1 MiB by default
    get() = allocator?.totalBytesAllocated?.toLong() ?: (1024L * 1024L)

  private fun startProgressUpdates() {
    stopProgressUpdates() // Ensure no multiple runnables
    progressRunnable = object : Runnable {
      override fun run() {
        if (releaseStarted.get()) return
        refreshSnapshot()
        if (player.playbackState != Player.STATE_IDLE && player.playbackState != Player.STATE_ENDED) {
          val currentTimeSeconds = player.currentPosition / 1000.0
          val bufferedDurationSeconds = player.bufferedPosition / 1000.0
          // bufferDuration is the time from current time that is buffered.
          val playableDurationFromNow = max(0.0, bufferedDurationSeconds - currentTimeSeconds)

          eventEmitter.onProgress(
            onProgressData(
              currentTime = currentTimeSeconds,
              bufferDuration = playableDurationFromNow
            )
          )
          progressHandler.postDelayed(this, PROGRESS_UPDATE_INTERVAL_MS)
        }
      }
    }
    progressHandler.post(progressRunnable ?: return)
  }

  private fun stopProgressUpdates() {
    progressRunnable?.let { progressHandler.removeCallbacks(it) }
    progressRunnable = null
  }

  private val analyticsListener = object: AnalyticsListener {
    override fun onBandwidthEstimate(
      eventTime: AnalyticsListener.EventTime,
      totalLoadTimeMs: Int,
      totalBytesLoaded: Long,
      bitrateEstimate: Long
    ) {
      val videoFormat = player.videoFormat
      eventEmitter.onBandwidthUpdate(
        BandwidthData(
          bitrate = bitrateEstimate.toDouble(),
          width = if (videoFormat != null) videoFormat.width.toDouble() else null,
          height = if (videoFormat != null) videoFormat.height.toDouble() else null
        )
      )
    }
  }

  private val playerListener = object : Player.Listener {
    override fun onEvents(player: Player, events: Player.Events) { refreshSnapshot() }
    override fun onPlaybackStateChanged(playbackState: Int) {
      val isPlayingUpdate = player.isPlaying
      val isBufferingUpdate = playbackState == Player.STATE_BUFFERING

      eventEmitter.onPlaybackStateChange(
        onPlaybackStateChangeData(
          isPlaying = isPlayingUpdate,
          isBuffering = isBufferingUpdate
        )
      )

      when (playbackState) {
        Player.STATE_IDLE -> {
          status = VideoPlayerStatus.IDLE
          eventEmitter.onBuffer(false)
        }
        Player.STATE_BUFFERING -> {
          status = VideoPlayerStatus.LOADING
          eventEmitter.onBuffer(true)
        }
        Player.STATE_READY -> {
          status = VideoPlayerStatus.READYTOPLAY
          eventEmitter.onBuffer(false)

          val generalVideoFormat = player.videoFormat
          val currentTracks = player.currentTracks

          val selectedVideoTrackGroup = currentTracks.groups.find { group -> group.type == C.TRACK_TYPE_VIDEO && group.isSelected }
          val selectedVideoTrackFormat = if (selectedVideoTrackGroup != null && selectedVideoTrackGroup.length > 0) {
            selectedVideoTrackGroup.getTrackFormat(0)
          } else {
            null
          }

          val width = selectedVideoTrackFormat?.width ?: generalVideoFormat?.width ?: 0
          val height = selectedVideoTrackFormat?.height ?: generalVideoFormat?.height ?: 0
          val rotationDegrees = selectedVideoTrackFormat?.rotationDegrees ?: generalVideoFormat?.rotationDegrees

          eventEmitter.onLoad(
            onLoadData(
              currentTime = player.currentPosition / 1000.0,
              duration = if (player.duration == C.TIME_UNSET) Double.NaN else player.duration / 1000.0,
              width = width.toDouble(),
              height = height.toDouble(),
              orientation = VideoOrientationUtils.fromWHR(width, height, rotationDegrees)
            )
          )
          // If player becomes ready and is set to play, start progress updates
          if (player.playWhenReady) {
            startProgressUpdates()
          }

          eventEmitter.onReadyToDisplay()
        }
        Player.STATE_ENDED -> {
          status = VideoPlayerStatus.IDLE // Or a specific 'COMPLETED' status if you add one
          eventEmitter.onEnd()
          eventEmitter.onBuffer(false)
          stopProgressUpdates()
        }
      }
    }

    override fun onIsPlayingChanged(isPlaying: Boolean) {
      super.onIsPlayingChanged(isPlaying)
      eventEmitter.onPlaybackStateChange(
        onPlaybackStateChangeData(
          isPlaying = isPlaying,
          isBuffering = player.playbackState == Player.STATE_BUFFERING
        )
      )
      if (isPlaying) {
        VideoManager.setLastPlayedPlayer(this@HybridVideoPlayer)
        startProgressUpdates()
      } else {
        if (player.playbackState == Player.STATE_ENDED || player.playbackState == Player.STATE_IDLE) {
          stopProgressUpdates()
        }
      }
      // Keep the activity's auto-enter-PiP flag in sync with the last-played video.
      VideoManager.refreshPictureInPictureParams()
    }

    override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
      super.onPlayWhenReadyChanged(playWhenReady, reason)

      // A resume cancels a pending auto-pause, so the next foreground won't force-resume it.
      if (playWhenReady) {
        this@HybridVideoPlayer.wasAutoPaused = false
      }

      // playWhenReady can change without isPlaying (pause while buffering), so refresh here too.
      VideoManager.refreshPictureInPictureParams()
    }

    override fun onPlayerError(error: PlaybackException) {
      // Emit onError only on the transition into ERROR, so one failure is reported once.
      // Load promises reject instead and never set the error status here.
      val wasError = status == VideoPlayerStatus.ERROR
      status = VideoPlayerStatus.ERROR
      if (!wasError) {
        eventEmitter.onError(PlayerError.PlaybackFailed(error.errorCodeName, error.message).message!!)
      }
      stopProgressUpdates()
    }

    override fun onPositionDiscontinuity(
      oldPosition: Player.PositionInfo,
      newPosition: Player.PositionInfo,
      reason: Int
    ) {
      if (reason == Player.DISCONTINUITY_REASON_SEEK || reason == Player.DISCONTINUITY_REASON_SEEK_ADJUSTMENT) {
        eventEmitter.onSeek(newPosition.positionMs / 1000.0)
      }
      // Update progress immediately after a discontinuity if needed by your logic
       val currentTimeSeconds = newPosition.positionMs / 1000.0
       val bufferedDurationSeconds = player.bufferedPosition / 1000.0
       eventEmitter.onProgress(
         onProgressData(
           currentTime = currentTimeSeconds,
           bufferDuration = max(0.0, bufferedDurationSeconds - currentTimeSeconds)
         )
       )
    }

    override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) {
      eventEmitter.onPlaybackRateChange(playbackParameters.speed.toDouble())
    }

    override fun onVolumeChanged(volume: Float) {
      // We get here device volume changes, and if
      // player is not muted we will sync it
      if (!muted) {
        this@HybridVideoPlayer.volume = volume.toDouble()
      }

      VideoManager.audioFocusManager.requestAudioFocusUpdate()
      eventEmitter.onVolumeChange(onVolumeChangeData(
        volume = volume.toDouble(),
        muted = muted
      ))
    }

    override fun onCues(cueGroup: CueGroup) {
      val texts = cueGroup.cues.mapNotNull { it.text?.toString() }
      if (texts.isNotEmpty()) {
        eventEmitter.onTextTrackDataChanged(texts.toTypedArray())
      }
    }

    override fun onMetadata(metadata: Metadata) {
      val timedMetadataObjects = mutableListOf<TimedMetadataObject>()
      for (i in 0 until metadata.length()) {
        val entry = metadata.get(i)

        when (entry) {
          is Id3Frame -> {
            var value = ""

            if (entry is TextInformationFrame) {
              value = entry.values.first()
            }

            timedMetadataObjects.add(TimedMetadataObject(entry.id, value))
          }
          is EventMessage ->
            timedMetadataObjects.add(TimedMetadataObject(entry.schemeIdUri, entry.value))
          else -> Log.d(TAG, "Unknown metadata: $entry")
        }
      }
      if (timedMetadataObjects.isNotEmpty()) {
        eventEmitter.onTimedMetadata(TimedMetadata(metadata = timedMetadataObjects.toTypedArray()))
      }
    }

    override fun onTracksChanged(tracks: Tracks) {
      super.onTracksChanged(tracks)
    }
  }

  // MARK: - Text Track Management

  override fun getAvailableTextTracks(): Array<TextTrack> = snapshot.tracks.copyOf()

  override fun selectTextTrack(textTrack: Variant_NullType_TextTrack): Promise<Unit> = Promise.async(ownerScope) {
    awaitOwner()
    selectedExternalTrackIndex = TextTrackUtils.selectTextTrack(
      player = player,
      textTrack = textTrack.asSecondOrNull(),
      source = source,
      onTrackChange = { track -> eventEmitter.onTrackChange(track) }
    )
  }

  override val selectedTrack: TextTrack?
    get() = snapshot.selected
}
