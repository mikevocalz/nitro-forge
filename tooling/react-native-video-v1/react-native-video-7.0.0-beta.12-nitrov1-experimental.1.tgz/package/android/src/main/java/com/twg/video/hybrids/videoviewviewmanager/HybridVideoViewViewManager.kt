package com.margelo.nitro.video

import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import com.facebook.proguard.annotations.DoNotStrip
import com.twg.video.core.VideoManager
import com.twg.video.core.VideoViewError
import com.twg.video.core.utils.PictureInPictureUtils
import com.twg.video.core.utils.Threading
import com.margelo.nitro.core.Callback
import com.margelo.nitro.core.invoke
import java.util.UUID
import java.util.concurrent.CopyOnWriteArrayList
import com.margelo.nitro.core.Promise
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import com.twg.video.view.VideoView
import java.lang.ref.WeakReference

data class ViewListenerPair(
  val id: UUID,
  val eventName: String,
  val callback: Any
)

@DoNotStrip
@OptIn(UnstableApi::class)
class HybridVideoViewViewManager(private val nitroId: Int): HybridVideoViewViewManagerSpec(), VideoViewEventsEmitter {
  companion object : HybridVideoViewViewManagerSpec.Companion

  private var videoView = WeakReference<VideoView>(null)
  private val listeners = CopyOnWriteArrayList<ViewListenerPair>()
  private val ownerScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
  @Volatile override var player: HybridVideoPlayerSpec? = null
  @Volatile private var options = NativeViewOptions(false, false, false, ResizeMode.NONE, true, SurfaceType.SURFACE)
  override val controls: Boolean get() = options.controls
  override val pictureInPicture: Boolean get() = options.pictureInPicture
  override val autoEnterPictureInPicture: Boolean get() = options.autoEnterPictureInPicture
  override val resizeMode: ResizeMode get() = options.resizeMode
  override val keepScreenAwake: Boolean get() = options.keepScreenAwake
  override val surfaceType: SurfaceType get() = options.surfaceType

  private fun requireView(): VideoView {
    videoView.get()?.let { return it }
    val view = VideoManager.getVideoViewWeakReferenceByNitroId(nitroId)?.get()
      ?: throw VideoViewError.ViewNotFound(nitroId)
    videoView = WeakReference(view)
    view.eventsEmitter = this
    return view
  }

  override fun applyProps(options: NativeViewOptions, player: Variant_HybridVideoPlayerSpec_NullType): Promise<Unit> = Promise.async(ownerScope) {
    val native = player.asFirstOrNull() as? HybridVideoPlayer
    native?.awaitOwner()
    val view = requireView()
    this@HybridVideoViewViewManager.player = native
    this@HybridVideoViewViewManager.options = options
    view.hybridPlayer = native
    view.useController = options.controls
    view.pictureInPictureEnabled = options.pictureInPicture
    view.autoEnterPictureInPicture = options.autoEnterPictureInPicture
    view.resizeMode = options.resizeMode
    view.keepScreenAwake = options.keepScreenAwake
    view.surfaceType = options.surfaceType
  }
  override fun canEnterPictureInPicture(): Promise<Boolean> = Promise.async(ownerScope) { PictureInPictureUtils.canEnterPictureInPicture() }
  override fun enterFullscreen(): Promise<Unit> = Promise.async(ownerScope) { requireView().enterFullscreen() }
  override fun exitFullscreen(): Promise<Unit> = Promise.async(ownerScope) { requireView().exitFullscreen() }
  override fun enterPictureInPicture(): Promise<Unit> = Promise.async(ownerScope) { requireView().enterPictureInPicture() }
  override fun exitPictureInPicture(): Promise<Unit> = Promise.async(ownerScope) { requireView().exitPictureInPicture() }

  // MARK: - Private helpers

  private fun <T> addListener(eventName: String, listener: T): ListenerSubscription {
    val id = UUID.randomUUID()
    listeners.add(ViewListenerPair(id, eventName, listener as Any))
    return ListenerSubscription(Callback.native<() -> Unit> {
      listeners.removeAll { it.id == id }
    })
  }

  @Suppress("UNCHECKED_CAST")
  private fun <T> emitEvent(eventName: String, invoke: (T) -> Unit) {
    listeners.filter { it.eventName == eventName }.forEach { pair ->
      try {
        invoke(pair.callback as T)
      } catch (e: Exception) {
        println("[ReactNativeVideo] Error calling $eventName listener: $e")
      }
    }
  }

  // MARK: - Listener registration methods

  override fun addOnPictureInPictureChangeListener(listener: Callback<(Boolean) -> Unit>): ListenerSubscription {
    return addListener("onPictureInPictureChange", listener)
  }

  override fun addOnFullscreenChangeListener(listener: Callback<(Boolean) -> Unit>): ListenerSubscription {
    return addListener("onFullscreenChange", listener)
  }

  override fun addWillEnterFullscreenListener(listener: Callback<() -> Unit>): ListenerSubscription {
    return addListener("willEnterFullscreen", listener)
  }

  override fun addWillExitFullscreenListener(listener: Callback<() -> Unit>): ListenerSubscription {
    return addListener("willExitFullscreen", listener)
  }

  override fun addWillEnterPictureInPictureListener(listener: Callback<() -> Unit>): ListenerSubscription {
    return addListener("willEnterPictureInPicture", listener)
  }

  override fun addWillExitPictureInPictureListener(listener: Callback<() -> Unit>): ListenerSubscription {
    return addListener("willExitPictureInPicture", listener)
  }

  override fun clearAllListeners() {
    listeners.clear()
  }

  // MARK: - Event emission methods (called by VideoView)

  override fun onPictureInPictureChange(isActive: Boolean) {
    emitEvent<Callback<(Boolean) -> Unit>>("onPictureInPictureChange") { it(isActive) }
  }

  override fun onFullscreenChange(isActive: Boolean) {
    emitEvent<Callback<(Boolean) -> Unit>>("onFullscreenChange") { it(isActive) }
  }

  override fun willEnterFullscreen() {
    emitEvent<Callback<() -> Unit>>("willEnterFullscreen") { it() }
  }

  override fun willExitFullscreen() {
    emitEvent<Callback<() -> Unit>>("willExitFullscreen") { it() }
  }

  override fun willEnterPictureInPicture() {
    emitEvent<Callback<() -> Unit>>("willEnterPictureInPicture") { it() }
  }

  override fun willExitPictureInPicture() {
    emitEvent<Callback<() -> Unit>>("willExitPictureInPicture") { it() }
  }

  override val memorySize: Long
    get() = 0
}

interface VideoViewEventsEmitter {
  fun onPictureInPictureChange(isActive: Boolean)
  fun onFullscreenChange(isActive: Boolean)
  fun willEnterFullscreen()
  fun willExitFullscreen()
  fun willEnterPictureInPicture()
  fun willExitPictureInPicture()
}
