public import AVFoundation
public import Foundation

/// Native plugin handle. Configuration and resource owner cannot disagree.
public struct VideoSourceHandle: Sendable {
  let owner: VideoSourceOwner
  public var config: NativeVideoConfig { owner.config }
  public var url: URL { owner.url }
  init(owner: VideoSourceOwner) { self.owner = owner }
  public init(config: NativeVideoConfig, drm: (any DRMManagerSpec)? = nil) throws {
    guard let url = URL(string: config.uri) else { throw SourceError.invalidUri(uri: config.uri).error() }
    if config.drm != nil && drm == nil { throw LibraryError.DRMPluginNotFound.error() }
    owner = VideoSourceOwner(config: config, url: url, photoLoader: PhotoLibraryAssetLoader(), drm: drm)
  }
  @MainActor public func getAsset() async throws -> AVAsset { try await owner.snapshot() }
  @MainActor public func replaceAsset(_ asset: sending AVAsset) { owner.replaceAsset(asset) }
  public func releaseAsset() { owner.release() }
}
