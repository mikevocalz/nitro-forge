//
//  NativeVideoPlayerSourceSpec.swift
//  react-native-video
//
// Created by Krzysztof Moch on 23/07/2025.
//

public import Foundation
public import AVFoundation

// Helper alias that allow to represet player source outside of module
public typealias NativeVideoPlayerSource = NativeVideoPlayerSourceSpec & HybridVideoPlayerSourceSpec

public protocol NativeVideoPlayerSourceSpec {
  // MARK: - Properties
  
  /// Replace the actor-owned asset with an exclusively transferred asset.
  func replaceAsset(_ asset: sending AVAsset) async
  
  /// The URL of the video source
  var url: URL { get }
  
  /// The memory size used by the source
  var memorySize: Int { get }
  
  // MARK: - Methods
  
  /// Initialize the asset asynchronously
  func initializeAsset() async throws
  
  /// Get non-null AVAsset instance (self.asset)
  @MainActor func getAsset() async throws -> AVAsset
  
  /// Release the asset resources
  func releaseAsset()
} 
