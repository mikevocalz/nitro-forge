public import AVFoundation
import Foundation
import os

/// Owns each mutable loading lifecycle. Consumers receive independent immutable snapshots.
@MainActor
final class VideoSourceOwner {
  nonisolated let config: NativeVideoConfig
  nonisolated let url: URL
  private let photoLoader: any PhotoLibraryAssetLoading
  private let drm: (any DRMManagerSpec)?
  private var asset: AVAsset?
  private var request: VideoSourceRequest?
  private nonisolated let current = OSAllocatedUnfairLock<VideoSourceRequest?>(initialState: nil)
  private nonisolated let estimate = OSAllocatedUnfairLock(initialState: 0)

  nonisolated init(config: NativeVideoConfig, url: URL,
       photoLoader: any PhotoLibraryAssetLoading, drm: (any DRMManagerSpec)?) {
    self.config = config
    self.url = url
    self.photoLoader = photoLoader
    self.drm = drm
  }

  nonisolated var memorySize: Int { estimate.withLock { $0 } }

  nonisolated func release() {
    let previous = current.withLock { value in
      let previous = value
      value = nil
      return previous
    }
    previous?.cancel()
    // Invalidate synchronously, then release actor-owned assets on their owner.
    Task { await self.clearReleased(previous) }
  }

  private func clearReleased(_ previous: VideoSourceRequest?) {
    guard request === previous else { return }
    request = nil
    asset = nil
    estimate.withLock { $0 = 0 }
  }

  func replaceAsset(_ replacement: sending AVAsset) {
    request?.cancel()
    let token = VideoSourceRequest()
    request = token
    let previous = current.withLock { value in
      let previous = value
      value = token
      return previous
    }
    previous?.cancel()
    asset = replacement
    let size = replacement.estimatedMemoryUsage
    estimate.withLock { $0 = size }
  }

  private func ensureAsset() async throws {
    if asset != nil, let request {
      do { try request.check(); return } catch { asset = nil }
    }
    let token = VideoSourceRequest()
    let previous = current.withLock { value in
      let previous = value
      value = token
      return previous
    }
    previous?.cancel()
    request = token
    let task = Task {
      if url.isFileURL { try VideoFileHelper.validateReadPermission(for: url) }
      let prepared: AVAsset
      if url.scheme?.lowercased() == "ph" {
        let item = try await photoLoader.loadPlayerItem(for: config.uri)
        prepared = item.asset
      } else if let headers = config.headers {
        prepared = AVURLAsset(url: url, options: ["AVURLAssetHTTPHeaderFieldsKey": headers])
      } else {
        prepared = AVURLAsset(url: url)
      }
      try token.check()
      if let params = config.drm {
        guard let urlAsset = prepared as? AVURLAsset else {
          throw SourceError.unsupportedContentType(uri: config.uri).error()
        }
        guard let drm else { throw LibraryError.DRMPluginNotFound.error() }
        try drm.createContentKeyRequest(for: urlAsset, drmParams: params)
      }
      _ = try await prepared.load(.duration, .preferredTransform, .isPlayable)
      try token.check()
      guard request === token else { throw CancellationError() }
      asset = prepared
      let size = prepared.estimatedMemoryUsage
      estimate.withLock { $0 = size }
    }
    token.install(task)
    do {
      try await withTaskCancellationHandler {
        try await task.value
        try token.check()
      } onCancel: { token.cancel() }
      token.finish()
    } catch {
      token.cancel()
      if request === token {
        request = nil
        asset = nil
        estimate.withLock { $0 = 0 }
      }
      throw error
    }
  }

  func snapshot() async throws -> AVAsset {
    try await ensureAsset()
    guard let asset, let snapshot = asset.copy() as? AVAsset else {
      throw SourceError.failedToInitializeAsset.error()
    }
    return snapshot
  }

  func initialize() async throws { try await ensureAsset() }

  func information() async throws -> VideoInformation {
    try await ensureAsset()
    guard let asset else { throw SourceError.failedToInitializeAsset.error() }
    return try await asset.getAssetInformation()
  }
}
