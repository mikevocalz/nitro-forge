//
//  HybridVideoPlayer.swift
//  ReactNativeVideo
//
//  Created by Krzysztof Moch on 09/10/2024.
//

import AVFoundation
import Foundation
import NitroModules

@MainActor
final class VideoPlayerCore {

  /**
   * Player instance for video playback
   */
  nonisolated let player: AVPlayer
  private let snapshot: VideoPlayerSnapshot

  var loopTask: Task<Void, Never>?
  var playerObserver: VideoPlayerObserver?
  private let sourceLoader = SourceLoader()
  private var storedSource: VideoSourceHandle
  private var storedPlayerItem: AVPlayerItem?
  private var storedStatus: VideoPlayerStatus = .idle

  private struct LoadContext {
    let source: VideoSourceHandle
    let token: SourceLoader.Token
  }

  private struct LoadedPlayerItem {
    let item: AVPlayerItem
    let context: LoadContext
  }

  private func actorOperation<T>(_ body: () throws -> T) rethrows -> T { try body() }

  private func beginLoad() throws -> LoadContext {
    try actorOperation {
      var source: (VideoSourceHandle)?
      guard let token = try sourceLoader.begin(onBegin: {
        source = storedSource
      }), let source else { throw CancellationError() }
      return LoadContext(source: source, token: token)
    }
  }

  private func beginLoadIfPlayerItemMissing() throws -> LoadContext? {
    try actorOperation {
      var source: (VideoSourceHandle)?
      guard let token = try sourceLoader.begin(
        if: { storedPlayerItem == nil },
        onBegin: { source = storedSource }
      ) else { return nil }
      guard let source else { throw CancellationError() }
      return LoadContext(source: source, token: token)
    }
  }

  private func beginPreloadIfNeeded() throws -> LoadContext? {
    try actorOperation {
      var source: (VideoSourceHandle)?
      guard let token = try sourceLoader.begin(
        if: { storedStatus == .idle },
        onBegin: { source = storedSource }
      ) else { return nil }
      guard let source else { throw CancellationError() }
      return LoadContext(source: source, token: token)
    }
  }

  private func replaceSourceAndBeginLoad(
    with newSource: VideoSourceHandle
  ) throws -> LoadContext {
    try actorOperation {
      var previousSource: (VideoSourceHandle)?
      guard let token = try sourceLoader.begin(onBegin: {
        previousSource = storedSource
        storedSource = newSource
      }), let previousSource else { throw CancellationError() }
      let context = LoadContext(source: newSource, token: token)
      releaseAssetIfNotUsedByCurrentLoad(for: previousSource)
      return context
    }
  }

  private func ensureCurrentLoad(_ context: LoadContext) throws {
    guard sourceLoader.isCurrent(context.token) else { throw CancellationError() }
  }

  private func releaseAssetIfNotUsedByCurrentLoad(
    for source: VideoSourceHandle
  ) {
    let currentSource = sourceLoader.withState { storedSource }
    guard currentSource.owner !== source.owner else { return }
    releaseAsset(for: source)
  }

  private func releaseAsset(for source: VideoSourceHandle) {
    source.releaseAsset()
  }

  private func close() -> (VideoSourceHandle)? {
    actorOperation {
      sourceLoader.close(update: { storedSource })
    }
  }

  nonisolated init(source: VideoSourceHandle, events: VideoEventSink, snapshot: VideoPlayerSnapshot) {
    self.storedSource = source
    self.events = events
    self.snapshot = snapshot
    self.player = AVPlayer()
  }

  func start() {
    guard !snapshot.isClosed else { return }
    playerObserver = VideoPlayerObserver(delegate: self)
    playerObserver?.initializePlayerObservers()
    VideoManager.shared.register(player: self)
  }

  isolated deinit { releaseOnMainThread() }

  // MARK: - Hybrid Impl

  var source: VideoSourceHandle {
    get { sourceLoader.withState { storedSource } }
    set {
      let releasedSource = actorOperation {
        sourceLoader.cancel {
          let releasedSource = storedSource
          storedSource = newValue
          return releasedSource
        }
      }
      withExtendedLifetime(releasedSource) {}
    }
  }

  var playerItem: AVPlayerItem? {
    get { sourceLoader.withState { storedPlayerItem } }
    set {
      sourceLoader.withState { storedPlayerItem = newValue }
      if let bufferConfig = source.config.bufferConfig {
        newValue?.setBufferConfig(config: bufferConfig)
      }
    }
  }

  var status: VideoPlayerStatus {
    get { sourceLoader.withState { storedStatus } }
    set {
      let previous = sourceLoader.withState { () -> VideoPlayerStatus in
        let previous = storedStatus
        storedStatus = newValue
        return previous
      }
      if newValue != previous {
        _eventEmitter?.onStatusChange(newValue)
      }
    }
  }

  /// Reports an asynchronous failure of the current item (e.g. a 404): sets the error status
  /// and emits `onError` only on the transition into `.error`, so a failure seen by several
  /// observers is reported once. Load promises reject instead and never call this.
  func reportAsyncError(_ error: Error?) {
    let previous = sourceLoader.withState { () -> VideoPlayerStatus in
      let previous = storedStatus
      storedStatus = .error
      return previous
    }
    guard previous != .error else { return }
    _eventEmitter?.onStatusChange(.error)
    _eventEmitter?.onError(PlayerError.playbackFailed(error: error).getMessage())
  }

  var isReleased: Bool { snapshot.isClosed || sourceLoader.isClosed }

  private let events: VideoEventSink
  var _eventEmitter: VideoEventSink? { events }

  var volume: Double {
    set {
      player.volume = Float(newValue)
    }
    get {
      return Double(player.volume)
    }
  }

  var muted: Bool {
    set {
      player.isMuted = newValue
      _eventEmitter?.onVolumeChange(
        onVolumeChangeData(
          volume: Double(player.volume),
          muted: muted
        )
      )
    }
    get {
      return player.isMuted
    }
  }

  var currentTime: Double {
    set {
      player.seek(
        to: CMTime(seconds: newValue, preferredTimescale: 1000),
        toleranceBefore: .zero,
        toleranceAfter: .zero
      ) { [weak self] completed in
        DispatchQueue.main.async {
          guard let self, completed, !self.isReleased else { return }
          self.refreshSnapshot()
          self._eventEmitter?.onSeek(self.player.currentTime().seconds)
        }
      }
    }
    get {
      player.currentTime().seconds
    }
  }

  var duration: Double {
    Double(player.currentItem?.duration.seconds ?? Double.nan)
  }

  var rate: Double {
    set {
      guard newValue > 0 else { player.pause(); return }
      if #available(iOS 16.0, tvOS 16.0, *) {
        player.defaultRate = Float(newValue)
      }

      player.rate = Float(newValue)
    }
    get {
      return Double(player.rate)
    }
  }

  var loop: Bool = false

  var mixAudioMode: MixAudioMode = .auto {
    didSet {
      VideoManager.shared.requestAudioSessionUpdate()
    }
  }

  var ignoreSilentSwitchMode: IgnoreSilentSwitchMode = .auto {
    didSet {
      VideoManager.shared.requestAudioSessionUpdate()
    }
  }

  var playInBackground: Bool = false {
    didSet {
      VideoManager.shared.requestAudioSessionUpdate()
    }
  }

  var playWhenInactive: Bool = false

  var disableAudioSessionManagement: Bool = false {
    didSet {
      VideoManager.shared.requestAudioSessionUpdate()
    }
  }

  var wasAutoPaused: Bool = false

  /// Whether the player was playing when backgrounded — used to resume it on
  /// return if the system paused background playback.
  var wasPlayingInBackground: Bool = false

  // Text track selection state
  private var selectedExternalTrackIndex: Int? = nil

  var isCurrentlyBuffering: Bool = false

  var isPlaying: Bool {
    return player.rate != 0
  }

  var showNotificationControls: Bool = false {
    didSet {
      let nativePlayer = player
      if showNotificationControls {
        NowPlayingInfoCenterManager.shared.registerPlayer(player: nativePlayer)
      } else {
        NowPlayingInfoCenterManager.shared.removePlayer(player: nativePlayer)
      }
    }
  }

  func initialize() async throws {
    guard !isReleased else { throw PlayerError.cancelled.error() }
    guard let context = try beginLoadIfPlayerItemMissing() else { return }
    let loaded = try await loadPlayerItem(for: context)
    try await commitPlayerItem(loaded)
  }

  func release() {
    guard let source = close() else { return }
    source.releaseAsset()
    releaseOnMainThread()
  }

  private func releaseOnMainThread() {
    loopTask?.cancel()
    loopTask = nil
    playerItem?.cancelPendingSeeks()
    playerObserver?.invalidatePlayerItemObservers()
    playerObserver?.invalidatePlayerObservers()
    playerObserver = nil

    NowPlayingInfoCenterManager.shared.removePlayer(player: player)
    playerItem = nil
    player.replaceCurrentItem(with: nil)
    status = .idle

    VideoManager.shared.unregister(player: self)
  }

  private func commitPlayerItem(_ loaded: LoadedPlayerItem) async throws {
    guard !snapshot.isClosed else { throw CancellationError() }
    try sourceLoader.commit(loaded.context.token) { storedPlayerItem = loaded.item }
    if let buffer = loaded.context.source.config.bufferConfig { loaded.item.setBufferConfig(config: buffer) }
    player.replaceCurrentItem(with: loaded.item)
    refreshSnapshot()
  }

  private func loadPlayerItem(for context: LoadContext) async throws -> LoadedPlayerItem {
    try ensureCurrentLoad(context)
    let playerItem = try await sourceLoader.load(
      token: context.token
    ) {
      try self.ensureCurrentLoad(context)
      return try await self.initializePlayerItem(source: context.source, context: context)
    }
    try ensureCurrentLoad(context)
    return LoadedPlayerItem(item: playerItem, context: context)
  }

  func preload() async throws {
    guard !isReleased else { throw PlayerError.cancelled.error() }
    guard let context = try beginPreloadIfNeeded() else { return }
    let loaded = try await loadPlayerItem(for: context)
    try await commitPlayerItem(loaded)
  }

  func play() throws {
    guard !isReleased else { throw PlayerError.cancelled.error() }
    player.play()
  }

  func pause() throws {
    guard !isReleased else { throw PlayerError.cancelled.error() }
    wasPlayingInBackground = false
    player.pause()
  }

  func seekBy(time: Double) throws {
    guard let currentItem = player.currentItem else {
      throw PlayerError.notInitialized.error()
    }

    let currentItemTime = currentItem.currentTime()

    // Duration is NaN for live streams
    let fixedDurration = duration.isNaN ? Double.infinity : duration

    // Clap by <0, duration>
    let newTime = max(0, min(currentItemTime.seconds + time, fixedDurration))

    currentTime = newTime
  }

  func seekTo(time: Double) {
    guard !isReleased, time.isFinite else { return }
    currentTime = time
  }

  func replaceSource(_ source: VideoSourceHandle) async throws {
    guard !isReleased else { throw PlayerError.cancelled.error() }
    let context = try replaceSourceAndBeginLoad(with: source)
    player.pause()
    player.replaceCurrentItem(with: nil)
    storedPlayerItem = nil
    let loaded = try await loadPlayerItem(for: context)
    try await commitPlayerItem(loaded)
  }

  // MARK: - Methods

  func initializePlayerItem() async throws -> AVPlayerItem {
    let context = try beginLoad()
    return try await loadPlayerItem(for: context).item
  }

  private func initializePlayerItem(
    source: VideoSourceHandle,
    context: LoadContext
  ) async throws -> AVPlayerItem {
    let resolved = await PluginsRegistry.shared.overrideSource(source: source)
    try ensureCurrentLoad(context)
    let asset = try await resolved.getAsset()
    try ensureCurrentLoad(context)

    let playerItem: AVPlayerItem

    if let externalSubtitles = resolved.config.externalSubtitles,
      externalSubtitles.isEmpty == false
    {
      playerItem = try await AVPlayerItem.withExternalSubtitles(
        for: asset,
        config: resolved.config
      )
    } else {
      playerItem = AVPlayerItem(asset: asset)
    }
    try ensureCurrentLoad(context)

    if let metadata = resolved.config.metadata {
      let title = metadata.title
      let artist = metadata.artist
      let imageUri = metadata.imageUri

      DispatchQueue.main.async { [weak playerItem] in
        guard let playerItem else { return }
        var items: [AVMetadataItem] = []

        if let title {
          items.append(.make(identifier: .commonIdentifierTitle, value: title as NSString))
        }
        if let artist {
          items.append(.make(identifier: .commonIdentifierArtist, value: artist as NSString))
        }
        if !items.isEmpty {
          playerItem.externalMetadata = items
          NowPlayingInfoCenterManager.shared.updateStaticInfo(ifCurrentItem: playerItem)
        }
      }

      // Load artwork in background to not block player initialization
      if let imageUri, let imageUrl = URL(string: imageUri) {
        Task { [weak playerItem] in
          guard let (data, _) = try? await URLSession.shared.data(from: imageUrl) else {
            print("[RNV] Failed to load artwork from: \(imageUrl)")
            return
          }
          DispatchQueue.main.async {
            guard let playerItem else { return }
            playerItem.externalMetadata = playerItem.externalMetadata + [.make(identifier: .commonIdentifierArtwork, value: data as NSData)]
            NowPlayingInfoCenterManager.shared.updateStaticInfo(ifCurrentItem: playerItem)
          }
        }
      } else if let imageUri {
        print("[RNV] Invalid imageUri for artwork: \(imageUri)")
      }
    }

    return playerItem
  }

  // MARK: - Text Track Management

  func getAvailableTextTracks() throws -> [TextTrack] {
    guard let currentItem = player.currentItem else {
      return []
    }

    var tracks: [TextTrack] = []

    if let mediaSelection = currentItem.asset.mediaSelectionGroup(
      forMediaCharacteristic: .legible
    ) {
      for (index, option) in mediaSelection.options.enumerated() {
        let isSelected =
          currentItem.currentMediaSelection.selectedMediaOption(
            in: mediaSelection
          ) == option

        let name =
          option.commonMetadata.first(where: { $0.commonKey == .commonKeyTitle }
          )?.stringValue
          ?? option.displayName

        let isExternal =
          source.config.externalSubtitles?.contains { subtitle in
            name.contains(subtitle.label)
          } ?? false

        let trackId =
          isExternal
          ? "external-\(index)"
          : "builtin-\(option.displayName)-\(option.locale?.identifier ?? "unknown")"

        tracks.append(
          TextTrack(
            id: trackId,
            label: option.displayName,
            language: option.locale?.identifier,
            selected: isSelected
          )
        )
      }
    }

    return tracks
  }

  func selectTextTrack(textTrack: Variant_NullType_TextTrack) throws {
    guard let currentItem = player.currentItem else {
      throw PlayerError.notInitialized.error()
    }

    guard
      let mediaSelection = currentItem.asset.mediaSelectionGroup(
        forMediaCharacteristic: .legible
      )
    else {
      return
    }

    switch textTrack {
    case .first(_):
      currentItem.select(nil, in: mediaSelection)
      selectedExternalTrackIndex = nil
      _eventEmitter?.onTrackChange(.first(.null))
      return
    case .second(let textTrack):
      // If textTrack id is empty, deselect any selected track
      if textTrack.id.isEmpty {
        currentItem.select(nil, in: mediaSelection)
        selectedExternalTrackIndex = nil
        _eventEmitter?.onTrackChange(.first(.null))
        return
      }

      if textTrack.id.hasPrefix("external-") {
        let trackIndexStr = String(textTrack.id.dropFirst("external-".count))
        if let trackIndex = Int(trackIndexStr),
          trackIndex < mediaSelection.options.count
        {
          let option = mediaSelection.options[trackIndex]
          currentItem.select(option, in: mediaSelection)
          selectedExternalTrackIndex = trackIndex
          _eventEmitter?.onTrackChange(.second(textTrack))
        }
      } else if textTrack.id.hasPrefix("builtin-") {
        for option in mediaSelection.options {
          let optionId =
            "builtin-\(option.displayName)-\(option.locale?.identifier ?? "unknown")"
          if optionId == textTrack.id {
            currentItem.select(option, in: mediaSelection)
            selectedExternalTrackIndex = nil
            _eventEmitter?.onTrackChange(.second(textTrack))
            return
          }
        }
      }
    }
  }

  var selectedTrack: TextTrack? {
    guard let currentItem = player.currentItem else {
      return nil
    }

    guard
      let mediaSelection = currentItem.asset.mediaSelectionGroup(
        forMediaCharacteristic: .legible
      )
    else {
      return nil
    }

    guard
      let selectedOption = currentItem.currentMediaSelection
        .selectedMediaOption(in: mediaSelection)
    else {
      return nil
    }

    guard let index = mediaSelection.options.firstIndex(of: selectedOption)
    else {
      return nil
    }

    let isExternal =
      source.config.externalSubtitles?.contains { subtitle in
        selectedOption.displayName.contains(subtitle.label)
      } ?? false

    let trackId =
      isExternal
      ? "external-\(index)"
      : "builtin-\(selectedOption.displayName)-\(selectedOption.locale?.identifier ?? "unknown")"

    return TextTrack(
      id: trackId,
      label: selectedOption.displayName,
      language: selectedOption.locale?.identifier,
      selected: true
    )
  }

  func refreshSnapshot() {
    var value = snapshot.read { $0 }
    value.currentTime = currentTime
    value.duration = duration
    value.volume = volume
    value.muted = muted
    value.rate = rate
    value.isPlaying = isPlaying
    value.status = status
    value.isCurrentlyBuffering = isCurrentlyBuffering
    value.selectedTrack = selectedTrack
    value.memorySize = memorySize
    value.playerItem = playerItem
    value.wasAutoPaused = wasAutoPaused
    value.loop = loop
    value.mixAudioMode = mixAudioMode
    value.ignoreSilentSwitchMode = ignoreSilentSwitchMode
    value.playInBackground = playInBackground
    value.playWhenInactive = playWhenInactive
    value.disableAudioSessionManagement = disableAudioSessionManagement
    value.showNotificationControls = showNotificationControls
    value.tracks = (try? getAvailableTextTracks()) ?? []
    let native = value
    snapshot.update { value in
      guard !value.closed else { return }
      value = native
    }
  }

  func execute(_ action: @MainActor @Sendable (VideoPlayerCore) throws -> Void) throws {
    guard !isReleased else { throw PlayerError.cancelled.error() }
    try action(self)
    refreshSnapshot()
  }

  func seekExactly(to time: Double) async throws {
    guard !isReleased, let item = player.currentItem else { throw PlayerError.notInitialized.error() }
    guard time.isFinite, time >= 0 else { throw RuntimeError("Seek time must be finite and nonnegative") }
    let completed = await withTaskCancellationHandler {
      await withCheckedContinuation { continuation in
        player.seek(to: CMTime(seconds: time, preferredTimescale: 1_000_000), toleranceBefore: .zero, toleranceAfter: .zero) { done in
          continuation.resume(returning: done)
        }
      }
    } onCancel: { item.cancelPendingSeeks() }
    try Task.checkCancellation()
    guard completed, !isReleased, player.currentItem === item else { throw CancellationError() }
    refreshSnapshot()
    events.onSeek(player.currentTime().seconds)
  }

  // MARK: - Memory Management

  func dispose() {
    release()
  }

  var memorySize: Int {
    isReleased ? 0 : playerItem?.asset.estimatedMemoryUsage ?? 0
  }
}
