//
//  HybridVideoPlayerEventEmitter.swift
//  ReactNativeVideo
//
//  Created by Krzysztof Moch on 02/05/2025.
//

import Foundation
import NitroModules

private struct ListenerPair: Sendable {
  let id: UUID
  let eventName: String
  let callback: any Sendable
}

final class VideoEventSink: Sendable {
  private let listeners = ListenerStore<ListenerPair>()

  // MARK: - Private helpers

  private func addListener<T: Sendable>(eventName: String, listener: T) -> ListenerSubscription {
    let id = UUID()
    listeners.append(ListenerPair(id: id, eventName: eventName, callback: listener))
    return ListenerSubscription(remove: .native { [listeners] in
      listeners.removeAll { $0.id == id }
    })
  }

  private func emitEvent<T>(eventName: String, invoke: (T) throws -> Void) {
    for pair in listeners.snapshot() where pair.eventName == eventName {
      if let callback = pair.callback as? T {
        do {
          try invoke(callback)
        } catch {
          print("[ReactNativeVideo] Error calling \(eventName) listener: \(error)")
        }
      } else {
        print("[ReactNativeVideo] Invalid callback type for \(eventName)")
      }
    }
  }

  // MARK: - Listener registration methods

  func addOnAudioBecomingNoisyListener(listener: any Callback<(), Void>) throws -> ListenerSubscription {
    addListener(eventName: "onAudioBecomingNoisy", listener: listener)
  }

  func addOnAudioFocusChangeListener(listener: any Callback<Bool, Void>) throws -> ListenerSubscription {
    addListener(eventName: "onAudioFocusChange", listener: listener)
  }

  func addOnBandwidthUpdateListener(listener: any Callback<BandwidthData, Void>) throws -> ListenerSubscription {
    addListener(eventName: "onBandwidthUpdate", listener: listener)
  }

  func addOnBufferListener(listener: any Callback<Bool, Void>) throws -> ListenerSubscription {
    addListener(eventName: "onBuffer", listener: listener)
  }

  func addOnControlsVisibleChangeListener(listener: any Callback<Bool, Void>) throws -> ListenerSubscription {
    addListener(eventName: "onControlsVisibleChange", listener: listener)
  }

  func addOnEndListener(listener: any Callback<(), Void>) throws -> ListenerSubscription {
    addListener(eventName: "onEnd", listener: listener)
  }

  func addOnErrorListener(listener: any Callback<String, Void>) throws -> ListenerSubscription {
    addListener(eventName: "onError", listener: listener)
  }

  func addOnExternalPlaybackChangeListener(listener: any Callback<Bool, Void>) throws -> ListenerSubscription {
    addListener(eventName: "onExternalPlaybackChange", listener: listener)
  }

  func addOnLoadListener(listener: any Callback<onLoadData, Void>) throws -> ListenerSubscription {
    addListener(eventName: "onLoad", listener: listener)
  }

  func addOnLoadStartListener(listener: any Callback<onLoadStartData, Void>) throws -> ListenerSubscription {
    addListener(eventName: "onLoadStart", listener: listener)
  }

  func addOnPlaybackStateChangeListener(listener: any Callback<onPlaybackStateChangeData, Void>) throws -> ListenerSubscription {
    addListener(eventName: "onPlaybackStateChange", listener: listener)
  }

  func addOnPlaybackRateChangeListener(listener: any Callback<Double, Void>) throws -> ListenerSubscription {
    addListener(eventName: "onPlaybackRateChange", listener: listener)
  }

  func addOnProgressListener(listener: any Callback<onProgressData, Void>) throws -> ListenerSubscription {
    addListener(eventName: "onProgress", listener: listener)
  }

  func addOnReadyToDisplayListener(listener: any Callback<(), Void>) throws -> ListenerSubscription {
    addListener(eventName: "onReadyToDisplay", listener: listener)
  }

  func addOnSeekListener(listener: any Callback<Double, Void>) throws -> ListenerSubscription {
    addListener(eventName: "onSeek", listener: listener)
  }

  func addOnStatusChangeListener(listener: any Callback<VideoPlayerStatus, Void>) throws -> ListenerSubscription {
    addListener(eventName: "onStatusChange", listener: listener)
  }

  func addOnTimedMetadataListener(listener: any Callback<TimedMetadata, Void>) throws -> ListenerSubscription {
    addListener(eventName: "onTimedMetadata", listener: listener)
  }

  func addOnTextTrackDataChangedListener(listener: any Callback<[String], Void>) throws -> ListenerSubscription {
    addListener(eventName: "onTextTrackDataChanged", listener: listener)
  }

  func addOnTrackChangeListener(listener: any Callback<Variant_NullType_TextTrack, Void>) throws -> ListenerSubscription {
    addListener(eventName: "onTrackChange", listener: listener)
  }

  func addOnVolumeChangeListener(listener: any Callback<onVolumeChangeData, Void>) throws -> ListenerSubscription {
    addListener(eventName: "onVolumeChange", listener: listener)
  }

  func clearAllListeners() throws {
    listeners.removeAll()
  }

  // MARK: - Event emission methods

  func onAudioBecomingNoisy() {
    emitEvent(eventName: "onAudioBecomingNoisy") { (callback: any Callback<(), Void>) in callback.callAndForget(()) }
  }

  func onAudioFocusChange(_ hasFocus: Bool) {
    emitEvent(eventName: "onAudioFocusChange") { (callback: any Callback<Bool, Void>) in callback.callAndForget(hasFocus) }
  }

  func onBandwidthUpdate(_ data: BandwidthData) {
    emitEvent(eventName: "onBandwidthUpdate") { (callback: any Callback<BandwidthData, Void>) in callback.callAndForget(data) }
  }

  func onBuffer(_ isBuffering: Bool) {
    emitEvent(eventName: "onBuffer") { (callback: any Callback<Bool, Void>) in callback.callAndForget(isBuffering) }
  }

  func onControlsVisibleChange(_ isVisible: Bool) {
    emitEvent(eventName: "onControlsVisibleChange") { (callback: any Callback<Bool, Void>) in callback.callAndForget(isVisible) }
  }

  func onEnd() {
    emitEvent(eventName: "onEnd") { (callback: any Callback<(), Void>) in callback.callAndForget(()) }
  }

  func onError(_ error: String) {
    emitEvent(eventName: "onError") { (callback: any Callback<String, Void>) in callback.callAndForget(error) }
  }

  func onExternalPlaybackChange(_ isExternalPlaybackActive: Bool) {
    emitEvent(eventName: "onExternalPlaybackChange") { (callback: any Callback<Bool, Void>) in callback.callAndForget(isExternalPlaybackActive) }
  }

  func onLoad(_ data: onLoadData) {
    emitEvent(eventName: "onLoad") { (callback: any Callback<onLoadData, Void>) in callback.callAndForget(data) }
  }

  func onLoadStart(_ data: onLoadStartData) {
    emitEvent(eventName: "onLoadStart") { (callback: any Callback<onLoadStartData, Void>) in callback.callAndForget(data) }
  }

  func onPlaybackStateChange(_ data: onPlaybackStateChangeData) {
    emitEvent(eventName: "onPlaybackStateChange") { (callback: any Callback<onPlaybackStateChangeData, Void>) in callback.callAndForget(data) }
  }

  func onPlaybackRateChange(_ rate: Double) {
    emitEvent(eventName: "onPlaybackRateChange") { (callback: any Callback<Double, Void>) in callback.callAndForget(rate) }
  }

  func onProgress(_ data: onProgressData) {
    emitEvent(eventName: "onProgress") { (callback: any Callback<onProgressData, Void>) in callback.callAndForget(data) }
  }

  func onReadyToDisplay() {
    emitEvent(eventName: "onReadyToDisplay") { (callback: any Callback<(), Void>) in callback.callAndForget(()) }
  }

  func onSeek(_ position: Double) {
    emitEvent(eventName: "onSeek") { (callback: any Callback<Double, Void>) in callback.callAndForget(position) }
  }

  func onStatusChange(_ status: VideoPlayerStatus) {
    emitEvent(eventName: "onStatusChange") { (callback: any Callback<VideoPlayerStatus, Void>) in callback.callAndForget(status) }
  }

  func onTimedMetadata(_ metadata: TimedMetadata) {
    emitEvent(eventName: "onTimedMetadata") { (callback: any Callback<TimedMetadata, Void>) in callback.callAndForget(metadata) }
  }

  func onTextTrackDataChanged(_ tracks: [String]) {
    emitEvent(eventName: "onTextTrackDataChanged") { (callback: any Callback<[String], Void>) in callback.callAndForget(tracks) }
  }

  func onTrackChange(_ track: Variant_NullType_TextTrack) {
    emitEvent(eventName: "onTrackChange") { (callback: any Callback<Variant_NullType_TextTrack, Void>) in callback.callAndForget(track) }
  }

  func onVolumeChange(_ data: onVolumeChangeData) {
    emitEvent(eventName: "onVolumeChange") { (callback: any Callback<onVolumeChangeData, Void>) in callback.callAndForget(data) }
  }
}
