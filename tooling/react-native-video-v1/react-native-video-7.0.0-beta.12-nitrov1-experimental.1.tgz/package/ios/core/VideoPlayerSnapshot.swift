import AVFoundation
import Foundation
import os

final class VideoPlayerSnapshot: Sendable {
  struct State: Sendable {
    var closed = false
    var currentTime: Double = 0
    var duration: Double = .nan
    var status: VideoPlayerStatus = .idle
    var isPlaying = false
    var selectedTrack: TextTrack?
    var tracks: [TextTrack] = []
    var memorySize = 0
    var playerItem: AVPlayerItem?
    var showNotificationControls: Bool = false
    var volume: Double = 1
    var muted: Bool = false
    var loop: Bool = false
    var rate: Double = 1
    var mixAudioMode: MixAudioMode = .auto
    var ignoreSilentSwitchMode: IgnoreSilentSwitchMode = .auto
    var playInBackground: Bool = false
    var playWhenInactive: Bool = false
    var disableAudioSessionManagement: Bool = false
    var wasAutoPaused: Bool = false
    var isCurrentlyBuffering: Bool = false
  }
  private let state = OSAllocatedUnfairLock(initialState: State())
  var isClosed: Bool { state.withLock { $0.closed } }
  func read<T: Sendable>(_ read: @Sendable (State) -> T) -> T { state.withLock { read($0) } }
  func update(_ update: @Sendable (inout State) -> Void) { state.withLock { update(&$0) } }
  func close() -> Bool {
    state.withLock { state in
      guard !state.closed else { return false }
      state.closed = true
      state.isPlaying = false
      state.memorySize = 0
      state.playerItem = nil
      return true
    }
  }
}
