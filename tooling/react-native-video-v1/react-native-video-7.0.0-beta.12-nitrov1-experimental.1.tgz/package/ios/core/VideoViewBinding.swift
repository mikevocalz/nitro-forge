import AVFoundation
import AVKit
import Foundation

@MainActor
final class VideoViewBinding {
  private let nitroId: Double
  private let events: VideoViewEventSink
  private weak var view: VideoComponentView?
  nonisolated init(nitroId: Double, events: VideoViewEventSink) { self.nitroId = nitroId; self.events = events }
  private func requireView() throws -> VideoComponentView {
    if let view { return view }
    guard let view = VideoComponentView.globalViewsMap.object(forKey: NSNumber(value: nitroId)) else {
      throw VideoViewError.viewNotFound(nitroId: nitroId).error()
    }
    self.view = view
    return view
  }
  func apply(_ options: NativeViewOptions, player: VideoPlayerCore?, playerEvents: VideoEventSink?) throws {
    let view = try requireView()
    view.delegate = VideoViewDelegate(events: events, playerEvents: playerEvents)
    view.player = player?.player
    view.controls = options.controls
    view.allowsPictureInPicturePlayback = options.pictureInPicture
    view.autoEnterPictureInPicture = options.autoEnterPictureInPicture
    view.resizeMode = options.resizeMode
    view.keepScreenAwake = options.keepScreenAwake
  }
  func enterFullscreen() throws { try requireView().enterFullscreen() }
  func exitFullscreen() throws { try requireView().exitFullscreen() }
  func enterPictureInPicture() throws { try requireView().startPictureInPicture() }
  func exitPictureInPicture() throws { try requireView().stopPictureInPicture() }
  static func canEnterPictureInPicture() -> Bool { AVPictureInPictureController.isPictureInPictureSupported() }
}
