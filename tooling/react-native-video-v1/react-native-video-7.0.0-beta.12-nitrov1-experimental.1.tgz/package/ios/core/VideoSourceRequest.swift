import Foundation
import os

/// Cancellation may arrive from Nitro release, Swift cancellation, or source replacement.
/// Only the task handle and generation state are shared; AV assets stay with their actor.
final class VideoSourceRequest: Sendable {
  private struct State: Sendable {
    var cancelled = false
    var task: Task<Void, Error>?
  }
  private let state = OSAllocatedUnfairLock(initialState: State())

  func install(_ task: Task<Void, Error>) {
    let cancelled = state.withLock { state in
      if state.cancelled { return true }
      state.task = task
      return false
    }
    if cancelled { task.cancel() }
  }

  func check() throws {
    try Task.checkCancellation()
    if state.withLock({ $0.cancelled }) { throw CancellationError() }
  }

  func cancel() {
    let task = state.withLock { state in
      state.cancelled = true
      let task = state.task
      state.task = nil
      return task
    }
    task?.cancel()
  }

  func finish() {
    let task = state.withLock { state in
      let task = state.task
      state.task = nil
      return task
    }
    withExtendedLifetime(task) {}
  }
}
