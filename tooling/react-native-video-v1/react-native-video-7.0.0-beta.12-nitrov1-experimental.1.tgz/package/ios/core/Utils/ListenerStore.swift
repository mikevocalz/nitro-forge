import Foundation
import os

/// Callback handles are Sendable. Only the membership array crosses this lock.
final class ListenerStore<Element: Sendable>: Sendable {
  private let state = OSAllocatedUnfairLock(initialState: [Element]())

  func append(_ element: Element) {
    state.withLock { $0.append(element) }
  }

  func removeAll(where shouldBeRemoved: @Sendable (Element) -> Bool) {
    let removed = state.withLock { elements in
      let removed = elements.filter(shouldBeRemoved)
      elements.removeAll(where: shouldBeRemoved)
      return removed
    }
    // Callback destruction may re-enter the owner; release after unlocking.
    withExtendedLifetime(removed) {}
  }

  func removeAll() {
    let removed = state.withLock { elements in
      let removed = elements
      elements.removeAll()
      return removed
    }
    withExtendedLifetime(removed) {}
  }

  func snapshot() -> [Element] { state.withLock { $0 } }
}
