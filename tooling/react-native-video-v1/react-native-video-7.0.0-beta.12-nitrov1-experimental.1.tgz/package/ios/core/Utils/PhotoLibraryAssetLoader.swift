//
//  PhotoLibraryAssetLoader.swift
//  ReactNativeVideo
//

import AVFoundation
import Foundation
import Photos
import os

protocol PhotoLibraryAssetLoading: Sendable {
  func loadPlayerItem(for uri: String) async throws -> AVPlayerItem
}

struct PhotoLibraryAssetRequest: Sendable {
  let cancel: @Sendable () -> Void
}

protocol PhotoLibraryAssetClient: Sendable {
  func requestAsset(
    forLocalIdentifier identifier: String,
    options: PHVideoRequestOptions,
    completion: @escaping @Sendable (sending Result<AVPlayerItem, Error>) -> Void
  ) -> PhotoLibraryAssetRequest?
}

private struct SystemPhotoLibraryAssetClient: PhotoLibraryAssetClient {
  func requestAsset(
    forLocalIdentifier identifier: String,
    options: PHVideoRequestOptions,
    completion: @escaping @Sendable (sending Result<AVPlayerItem, Error>) -> Void
  ) -> PhotoLibraryAssetRequest? {
    guard let photoAsset = PHAsset.fetchAssets(
      withLocalIdentifiers: [identifier],
      options: nil
    ).firstObject,
      photoAsset.mediaType == .video
    else {
      return nil
    }

    let imageManager = PHImageManager.default()
    let requestID = imageManager.requestPlayerItem(
      forVideo: photoAsset,
      options: options
    ) { item, info in
      if let isCancelled = info?[PHImageCancelledKey] as? NSNumber,
         isCancelled.boolValue {
        completion(.failure(CancellationError()))
      } else if let error = info?[PHImageErrorKey] as? Error {
        completion(.failure(error))
      } else if let item {
        // Photos supplies a Sendable player item, including edited/composition assets.
        completion(.success(item))
      } else {
        completion(.failure(SourceError.failedToInitializeAsset.error()))
      }
    }

    return PhotoLibraryAssetRequest {
      imageManager.cancelImageRequest(requestID)
    }
  }
}

private final class PhotoLibraryAssetLoadState: Sendable {
  private enum Status: Sendable { case pending, completed, cancelled }
  private struct State: Sendable {
    var status: Status = .pending
    var continuation: CheckedContinuation<AVPlayerItem, Error>?
    var request: PhotoLibraryAssetRequest?
  }
  private let state = OSAllocatedUnfairLock(initialState: State())

  func installContinuation(_ continuation: CheckedContinuation<AVPlayerItem, Error>) {
    let shouldCancel = state.withLock { value in
      switch value.status {
      case .pending: value.continuation = continuation; return false
      case .cancelled: return true
      case .completed: return false
      }
    }
    if shouldCancel { continuation.resume(throwing: CancellationError()) }
  }

  func installRequest(_ request: PhotoLibraryAssetRequest) {
    let shouldCancel = state.withLock { value in
      switch value.status {
      case .pending: value.request = request; return false
      case .cancelled: return true
      case .completed: return false
      }
    }
    if shouldCancel { request.cancel() }
  }

  func complete(_ result: sending Result<AVPlayerItem, Error>) {
    let completion: (CheckedContinuation<AVPlayerItem, Error>?, PhotoLibraryAssetRequest?)? = state.withLock { value in
      guard case .pending = value.status else { return nil }
      value.status = .completed
      let completion = (value.continuation, value.request)
      value.continuation = nil; value.request = nil
      return completion
    }
    completion?.0?.resume(with: result)
    withExtendedLifetime(completion?.1) {}
  }

  func cancel() {
    let cancellation: (CheckedContinuation<AVPlayerItem, Error>?, PhotoLibraryAssetRequest?)? = state.withLock { value in
      guard case .pending = value.status else { return nil }
      value.status = .cancelled
      let cancellation = (value.continuation, value.request)
      value.continuation = nil; value.request = nil
      return cancellation
    }
    cancellation?.1?.cancel()
    cancellation?.0?.resume(throwing: CancellationError())
  }
}

final class PhotoLibraryAssetLoader: PhotoLibraryAssetLoading {
  private static let schemeDelimiter = "ph://"

  private let client: any PhotoLibraryAssetClient

  init() {
    client = SystemPhotoLibraryAssetClient()
  }

  init(client: any PhotoLibraryAssetClient) {
    self.client = client
  }

  func loadPlayerItem(for uri: String) async throws -> AVPlayerItem {
    guard uri.range(
      of: Self.schemeDelimiter,
      options: [.anchored, .caseInsensitive]
    ) != nil else {
      throw SourceError.invalidUri(uri: uri).error()
    }

    let identifier = String(uri.dropFirst(Self.schemeDelimiter.count))
    guard !identifier.isEmpty else {
      throw SourceError.invalidUri(uri: uri).error()
    }

    let options = PHVideoRequestOptions()
    options.isNetworkAccessAllowed = true
    let state = PhotoLibraryAssetLoadState()

    return try await withTaskCancellationHandler {
      try await withCheckedThrowingContinuation { continuation in
        state.installContinuation(continuation)
        guard !Task.isCancelled else {
          state.cancel()
          return
        }

        guard let request = client.requestAsset(
          forLocalIdentifier: identifier,
          options: options,
          completion: { result in
            state.complete(result)
          }
        ) else {
          state.complete(
            .failure(SourceError.photoLibraryAssetNotFound(uri: uri).error())
          )
          return
        }

        state.installRequest(request)
      }
    } onCancel: {
      state.cancel()
    }
  }
}
