//
//  HybridVideoViewViewManager.swift
//  ReactNativeVideo
//
//  Created by Krzysztof Moch on 23/09/2024.
//

import Foundation
import AVKit
import NitroModules

private struct ViewListenerPair: Sendable {
  let id: UUID
  let eventName: String
  let callback: any Sendable
}

final class VideoViewEventSink: Sendable {
  private let listeners = ListenerStore<ViewListenerPair>()

  // MARK: - Private helpers
  
  private func addListener<T: Sendable>(eventName: String, listener: T) -> ListenerSubscription {
    let id = UUID()
    listeners.append(ViewListenerPair(id: id, eventName: eventName, callback: listener))
    return ListenerSubscription(remove: .native { [listeners] in
      listeners.removeAll { $0.id == id }
    })
  }
  
  private func emitEvent<T>(eventName: String, invoke: (T) throws -> Void) {
    for pair in listeners.snapshot() where pair.eventName == eventName {
      if let callback = pair.callback as? T {
        do {
          try invoke(callback)
        } catch {
          print("[ReactNativeVideo] Error calling \(eventName) listener: \(error)")
        }
      } else {
        print("[ReactNativeVideo] Invalid callback type for \(eventName)")
      }
    }
  }
  
  // MARK: - Listener registration methods
  
  func addOnPictureInPictureChangeListener(listener: any Callback<Bool, Void>) throws -> ListenerSubscription {
    addListener(eventName: "onPictureInPictureChange", listener: listener)
  }
  
  func addOnFullscreenChangeListener(listener: any Callback<Bool, Void>) throws -> ListenerSubscription {
    addListener(eventName: "onFullscreenChange", listener: listener)
  }
  
  func addWillEnterFullscreenListener(listener: any Callback<(), Void>) throws -> ListenerSubscription {
    addListener(eventName: "willEnterFullscreen", listener: listener)
  }
  
  func addWillExitFullscreenListener(listener: any Callback<(), Void>) throws -> ListenerSubscription {
    addListener(eventName: "willExitFullscreen", listener: listener)
  }
  
  func addWillEnterPictureInPictureListener(listener: any Callback<(), Void>) throws -> ListenerSubscription {
    addListener(eventName: "willEnterPictureInPicture", listener: listener)
  }
  
  func addWillExitPictureInPictureListener(listener: any Callback<(), Void>) throws -> ListenerSubscription {
    addListener(eventName: "willExitPictureInPicture", listener: listener)
  }
  
  func clearAllListeners() throws {
    listeners.removeAll()
  }
  
  // MARK: - Event emission methods
  
  func onPictureInPictureChange(_ isActive: Bool) {
    emitEvent(eventName: "onPictureInPictureChange") { (callback: any Callback<Bool, Void>) in callback.callAndForget(isActive) }
  }
  
  func onFullscreenChange(_ isActive: Bool) {
    emitEvent(eventName: "onFullscreenChange") { (callback: any Callback<Bool, Void>) in callback.callAndForget(isActive) }
  }
  
  func willEnterFullscreen() {
    emitEvent(eventName: "willEnterFullscreen") { (callback: any Callback<(), Void>) in callback.callAndForget(()) }
  }
  
  func willExitFullscreen() {
    emitEvent(eventName: "willExitFullscreen") { (callback: any Callback<(), Void>) in callback.callAndForget(()) }
  }
  
  func willEnterPictureInPicture() {
    emitEvent(eventName: "willEnterPictureInPicture") { (callback: any Callback<(), Void>) in callback.callAndForget(()) }
  }
  
  func willExitPictureInPicture() {
    emitEvent(eventName: "willExitPictureInPicture") { (callback: any Callback<(), Void>) in callback.callAndForget(()) }
  }
}
