import Foundation

/// Playback load generations live on the same actor as item replacement.
@MainActor
final class SourceLoader {
  final class Token: Sendable {}
  private struct Request {
    let token: Token
    var cancel: (@Sendable () -> Void)?
  }
  private var request: Request?
  private(set) var isClosed = false

  func begin(if shouldBegin: () -> Bool = { true }, onBegin: () -> Void = {}) throws -> Token? {
    guard !isClosed else { throw CancellationError() }
    guard shouldBegin() else { return nil }
    let previous = request?.cancel
    let token = Token()
    request = Request(token: token)
    onBegin()
    previous?()
    return token
  }
  func withState<T>(_ operation: () throws -> T) rethrows -> T { try operation() }
  func isCurrent(_ token: Token) -> Bool { !isClosed && request?.token === token }
  func commit<T>(_ token: Token, update: () throws -> T) throws -> T {
    guard isCurrent(token) else { throw CancellationError() }
    return try update()
  }
  @discardableResult func cancel<T>(_ token: Token? = nil, update: () -> T) -> T? {
    guard !isClosed, token == nil || request?.token === token else { return nil }
    let previous = request?.cancel
    request = nil
    let result = update()
    previous?()
    return result
  }
  @discardableResult func close<T>(update: () -> T) -> T? {
    guard !isClosed else { return nil }
    isClosed = true
    let previous = request?.cancel
    request = nil
    let result = update()
    previous?()
    return result
  }
  func load<T: Sendable>(token: Token,
                        operation: @escaping @MainActor () async throws -> T) async throws -> T {
    guard isCurrent(token) else { throw CancellationError() }
    let task = Task { try await operation() }
    request?.cancel?()
    request?.cancel = { task.cancel() }
    do {
      let result = try await withTaskCancellationHandler {
        try await task.value
      } onCancel: { task.cancel() }
      try Task.checkCancellation()
      guard isCurrent(token) else { throw CancellationError() }
      request?.cancel = nil
      return result
    } catch {
      if isCurrent(token) { request?.cancel = nil }
      throw error
    }
  }
}
