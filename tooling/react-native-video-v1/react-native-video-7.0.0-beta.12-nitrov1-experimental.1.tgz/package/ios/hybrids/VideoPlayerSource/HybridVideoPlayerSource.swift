import AVFoundation
import Foundation
import NitroModules

/// Nitro facade. Only immutable configuration crosses the generated synchronous API.
final class HybridVideoPlayerSource: HybridVideoPlayerSourceSpec, NativeVideoPlayerSourceSpec {
  let uri: String
  let config: NativeVideoConfig
  let url: URL
  private(set) var owner: VideoSourceOwner!

  init(config: NativeVideoConfig,
       photoLibraryAssetLoader: any PhotoLibraryAssetLoading = PhotoLibraryAssetLoader()) throws {
    self.uri = config.uri
    self.config = config
    guard let url = URL(string: config.uri) else {
      throw SourceError.invalidUri(uri: config.uri).error()
    }
    self.url = url
    try super.init()
    let manager = config.drm == nil ? nil : try PluginsRegistry.shared.getDrmManager(source: self)
    if config.drm != nil && manager == nil { throw LibraryError.DRMPluginNotFound.error() }
    owner = VideoSourceOwner(config: config, url: url, photoLoader: photoLibraryAssetLoader, drm: manager)
  }

  var handle: VideoSourceHandle { .init(owner: owner) }

  deinit { owner?.release() }

  func getAssetInformationAsync() -> any Promise<VideoInformation> {
    let owner = owner!
    return Promise___ReactNativeVideo__VideoInformation.async {
      try await owner.information()
    }
  }

  func initializeAsset() async throws { try await owner.initialize() }
  @MainActor func getAsset() async throws -> AVAsset { try await owner.snapshot() }

  @MainActor func getAsset(isCurrent: @escaping () -> Bool) async throws -> AVAsset {
    guard isCurrent() else { throw CancellationError() }
    let asset = try await owner.snapshot()
    guard isCurrent() else { throw CancellationError() }
    return asset
  }

  func replaceAsset(_ asset: sending AVAsset) async { await owner.replaceAsset(asset) }
  func releaseAsset() { owner.release() }
  var memorySize: Int { owner.memorySize }
}
