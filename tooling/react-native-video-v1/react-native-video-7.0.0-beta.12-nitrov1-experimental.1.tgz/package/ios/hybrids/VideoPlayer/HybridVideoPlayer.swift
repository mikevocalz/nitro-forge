import AVFoundation
import Foundation
import NitroModules

/// Synchronous properties read local snapshots; native commands enter one owner asynchronously.
final class HybridVideoPlayer: HybridVideoPlayerSpec, NativeVideoPlayerSpec {
  let core: VideoPlayerCore
  private let snapshot = VideoPlayerSnapshot()
  let eventEmitter: any HybridVideoPlayerEventEmitterSpec
  let _eventEmitter: VideoEventSink?
  private let sourceLock = NSLock()
  private var storedSource: any HybridVideoPlayerSourceSpec

  init(source: any HybridVideoPlayerSourceSpec) throws {
    guard let source = source as? HybridVideoPlayerSource else { throw PlayerError.invalidSource.error() }
    storedSource = source
    let emitter = try HybridVideoPlayerEventEmitter()
    eventEmitter = emitter
    _eventEmitter = emitter.sink
    core = VideoPlayerCore(source: source.handle, events: emitter.sink, snapshot: snapshot)
    try super.init()
    let core = core
    DispatchQueue.main.async { core.start() }
    PluginsRegistry.shared.notifyPlayerCreated(player: self)
    if source.config.initializeOnCreation == true { _ = initialize() }
  }

  deinit { release() }
  var source: any HybridVideoPlayerSourceSpec {
    sourceLock.lock(); defer { sourceLock.unlock() }
    return storedSource
  }
  var player: AVPlayer { core.player }
  var playerItem: AVPlayerItem? {
    get { snapshot.read { $0.playerItem } }
    set { _ = command { $0.playerItem = newValue } }
  }
  var isReleased: Bool { snapshot.isClosed }
  var status: VideoPlayerStatus { snapshot.read { $0.status } }
  var duration: Double { snapshot.read { $0.duration } }
  var currentTime: Double { snapshot.read { $0.currentTime } }
  var isPlaying: Bool { snapshot.read { $0.isPlaying } }
  var selectedTrack: TextTrack? { snapshot.read { $0.selectedTrack } }
  var memorySize: Int { snapshot.read { $0.memorySize } }

  private func command(_ action: @escaping @MainActor @Sendable (VideoPlayerCore) throws -> Void) -> any Promise<Void> {
    let core = core
    guard !snapshot.isClosed else { return Promise_void.rejected(with: PlayerError.cancelled.error()) }
    return Promise_void.async { try await core.execute(action) }
  }

  func configure(options: NativePlayerOptions) -> any Promise<Void> {
    command { player in
      if let volume = options.volume, (!volume.isFinite || !(0...1).contains(volume)) {
        throw RuntimeError("Volume must be in 0...1")
      }
      if let rate = options.rate, (!rate.isFinite || rate < 0) {
        throw RuntimeError("Rate must be finite and nonnegative")
      }
      if let value = options.showNotificationControls { player.showNotificationControls = value }
      if let value = options.volume { player.volume = value }
      if let value = options.muted { player.muted = value }
      if let value = options.loop { player.loop = value }
      if let value = options.rate { player.rate = value }
      if let value = options.mixAudioMode { player.mixAudioMode = value }
      if let value = options.ignoreSilentSwitchMode { player.ignoreSilentSwitchMode = value }
      if let value = options.playInBackground { player.playInBackground = value }
      if let value = options.playWhenInactive { player.playWhenInactive = value }
      if let value = options.disableAudioSessionManagement { player.disableAudioSessionManagement = value }
    }
  }

  private func loadStarted() {
    let source = source
    let local = (source as? HybridVideoPlayerSource)?.url
    _eventEmitter?.onLoadStart(.init(sourceType: local?.isFileURL == true || local?.scheme == "ph" ? .local : .network, source: source))
  }

  func initialize() -> any Promise<Void> {
    guard !isReleased else { return Promise_void.rejected(with: PlayerError.cancelled.error()) }
    loadStarted()
    let core = core
    return Promise_void.async { try await core.initialize() }
  }
  func preload() -> any Promise<Void> {
    guard !isReleased else { return Promise_void.rejected(with: PlayerError.cancelled.error()) }
    loadStarted()
    let core = core
    return Promise_void.async { try await core.preload() }
  }
  func replaceSourceAsync(source: Variant__any_HybridVideoPlayerSourceSpec__NullType) throws -> any Promise<Void> {
    guard !isReleased else { return Promise_void.rejected(with: PlayerError.cancelled.error()) }
    switch source {
    case .second: release(); return Promise_void.resolved()
    case .first(let replacement):
      guard let replacement = replacement as? HybridVideoPlayerSource else { throw PlayerError.invalidSource.error() }
      sourceLock.lock()
      let previous = storedSource
      storedSource = replacement
      sourceLock.unlock()
      withExtendedLifetime(previous) {}
      loadStarted()
      let handle = replacement.handle, core = core
      return Promise_void.async { try await core.replaceSource(handle) }
    }
  }
  func release() {
    guard snapshot.close() else { return }
    try? _eventEmitter?.clearAllListeners()
    let core = core
    DispatchQueue.main.async { core.release() }
    PluginsRegistry.shared.notifyPlayerDestroyed(player: self)
  }
  func initializePlayerItem() async throws -> AVPlayerItem { try await core.initializePlayerItem() }
  func getAvailableTextTracks() -> [TextTrack] { snapshot.read { $0.tracks } }
  func selectTextTrack(textTrack: Variant_NullType_TextTrack) -> any Promise<Void> { command { try $0.selectTextTrack(textTrack: textTrack) } }
  func play() -> any Promise<Void> { command { try $0.play() } }
  func pause() -> any Promise<Void> { command { try $0.pause() } }
  func seekTo(time: Double) -> any Promise<Void> {
    let core = core
    return Promise_void.async { try await core.seekExactly(to: time) }
  }
  func seekBy(time: Double) -> any Promise<Void> {
    let core = core
    return Promise_void.async {
      let position = await core.currentTime
      try await core.seekExactly(to: max(0, position + time))
    }
  }
  var showNotificationControls: Bool { snapshot.read { $0.showNotificationControls } }
  var volume: Double { snapshot.read { $0.volume } }
  var muted: Bool { snapshot.read { $0.muted } }
  var loop: Bool { snapshot.read { $0.loop } }
  var rate: Double { snapshot.read { $0.rate } }
  var mixAudioMode: MixAudioMode { snapshot.read { $0.mixAudioMode } }
  var ignoreSilentSwitchMode: IgnoreSilentSwitchMode { snapshot.read { $0.ignoreSilentSwitchMode } }
  var playInBackground: Bool { snapshot.read { $0.playInBackground } }
  var playWhenInactive: Bool { snapshot.read { $0.playWhenInactive } }
  var disableAudioSessionManagement: Bool { snapshot.read { $0.disableAudioSessionManagement } }
  var wasAutoPaused: Bool {
    get { snapshot.read { $0.wasAutoPaused } }
    set {
      snapshot.update { $0.wasAutoPaused = newValue }
      _ = command { $0.wasAutoPaused = newValue }
    }
  }
  var isCurrentlyBuffering: Bool {
    get { snapshot.read { $0.isCurrentlyBuffering } }
    set {
      snapshot.update { $0.isCurrentlyBuffering = newValue }
      _ = command { $0.isCurrentlyBuffering = newValue }
    }
  }
}
