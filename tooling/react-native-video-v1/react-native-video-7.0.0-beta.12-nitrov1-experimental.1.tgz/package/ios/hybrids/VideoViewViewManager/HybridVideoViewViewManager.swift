import AVFoundation
import Foundation
import NitroModules

final class HybridVideoViewViewManager: HybridVideoViewViewManagerSpec {
  private let events = VideoViewEventSink()
  private let binding: VideoViewBinding
  private var storedPlayer: (any HybridVideoPlayerSpec)?
  private let lock = NSLock()
  private var options = NativeViewOptions(controls: false, pictureInPicture: false, autoEnterPictureInPicture: false, resizeMode: .none, keepScreenAwake: true, surfaceType: .surface)

  init(nitroId: Double) throws {
    binding = VideoViewBinding(nitroId: nitroId, events: events)
    try super.init()
  }
  var player: (any HybridVideoPlayerSpec)? { lock.lock(); defer { lock.unlock() }; return storedPlayer }
  private func readOptions<T>(_ read: (NativeViewOptions) -> T) -> T { lock.lock(); defer { lock.unlock() }; return read(options) }
  var controls: Bool { readOptions { $0.controls } }
  var pictureInPicture: Bool { readOptions { $0.pictureInPicture } }
  var autoEnterPictureInPicture: Bool { readOptions { $0.autoEnterPictureInPicture } }
  var resizeMode: ResizeMode { readOptions { $0.resizeMode } }
  var keepScreenAwake: Bool { readOptions { $0.keepScreenAwake } }
  var surfaceType: SurfaceType { readOptions { $0.surfaceType } }

  func applyProps(options: NativeViewOptions, player: Variant__any_HybridVideoPlayerSpec__NullType) throws -> any Promise<Void> {
    let native: HybridVideoPlayer?
    switch player {
    case .second: native = nil
    case .first(let player):
      guard let typed = player as? HybridVideoPlayer else { throw PlayerError.invalidSource.error() }
      native = typed
    }
    lock.lock(); let previous = storedPlayer; storedPlayer = native; self.options = options; lock.unlock()
    withExtendedLifetime(previous) {}
    let core = native?.core, playerEvents = native?._eventEmitter, binding = binding
    return Promise_void.async { try await binding.apply(options, player: core, playerEvents: playerEvents) }
  }
  func enterFullscreen() -> any Promise<Void> { let binding = binding; return Promise_void.async { try await binding.enterFullscreen() } }
  func exitFullscreen() -> any Promise<Void> { let binding = binding; return Promise_void.async { try await binding.exitFullscreen() } }
  func enterPictureInPicture() -> any Promise<Void> { let binding = binding; return Promise_void.async { try await binding.enterPictureInPicture() } }
  func exitPictureInPicture() -> any Promise<Void> { let binding = binding; return Promise_void.async { try await binding.exitPictureInPicture() } }
  func canEnterPictureInPicture() -> any Promise<Bool> { Promise_bool.async { await VideoViewBinding.canEnterPictureInPicture() } }
  func addOnPictureInPictureChangeListener(listener: any Callback<Bool, Void>) throws -> ListenerSubscription { try events.addOnPictureInPictureChangeListener(listener: listener) }
  func addOnFullscreenChangeListener(listener: any Callback<Bool, Void>) throws -> ListenerSubscription { try events.addOnFullscreenChangeListener(listener: listener) }
  func addWillEnterFullscreenListener(listener: any Callback<(), Void>) throws -> ListenerSubscription { try events.addWillEnterFullscreenListener(listener: listener) }
  func addWillExitFullscreenListener(listener: any Callback<(), Void>) throws -> ListenerSubscription { try events.addWillExitFullscreenListener(listener: listener) }
  func addWillEnterPictureInPictureListener(listener: any Callback<(), Void>) throws -> ListenerSubscription { try events.addWillEnterPictureInPictureListener(listener: listener) }
  func addWillExitPictureInPictureListener(listener: any Callback<(), Void>) throws -> ListenerSubscription { try events.addWillExitPictureInPictureListener(listener: listener) }
  func clearAllListeners() throws { try events.clearAllListeners() }
  func onPictureInPictureChange(_ isActive: Bool) { events.onPictureInPictureChange(isActive) }
  func onFullscreenChange(_ isActive: Bool) { events.onFullscreenChange(isActive) }
  func willEnterFullscreen() { events.willEnterFullscreen() }
  func willExitFullscreen() { events.willExitFullscreen() }
  func willEnterPictureInPicture() { events.willEnterPictureInPicture() }
  func willExitPictureInPicture() { events.willExitPictureInPicture() }
}
