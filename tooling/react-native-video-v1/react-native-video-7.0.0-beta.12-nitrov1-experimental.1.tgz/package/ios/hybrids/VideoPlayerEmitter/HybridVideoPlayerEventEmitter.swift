import Foundation
import NitroModules

final class HybridVideoPlayerEventEmitter: HybridVideoPlayerEventEmitterSpec {
  let sink = VideoEventSink()
  func addOnAudioBecomingNoisyListener(listener: any Callback<(), Void>) throws -> ListenerSubscription { try sink.addOnAudioBecomingNoisyListener(listener: listener) }
  func addOnAudioFocusChangeListener(listener: any Callback<Bool, Void>) throws -> ListenerSubscription { try sink.addOnAudioFocusChangeListener(listener: listener) }
  func addOnBandwidthUpdateListener(listener: any Callback<BandwidthData, Void>) throws -> ListenerSubscription { try sink.addOnBandwidthUpdateListener(listener: listener) }
  func addOnBufferListener(listener: any Callback<Bool, Void>) throws -> ListenerSubscription { try sink.addOnBufferListener(listener: listener) }
  func addOnControlsVisibleChangeListener(listener: any Callback<Bool, Void>) throws -> ListenerSubscription { try sink.addOnControlsVisibleChangeListener(listener: listener) }
  func addOnEndListener(listener: any Callback<(), Void>) throws -> ListenerSubscription { try sink.addOnEndListener(listener: listener) }
  func addOnErrorListener(listener: any Callback<String, Void>) throws -> ListenerSubscription { try sink.addOnErrorListener(listener: listener) }
  func addOnExternalPlaybackChangeListener(listener: any Callback<Bool, Void>) throws -> ListenerSubscription { try sink.addOnExternalPlaybackChangeListener(listener: listener) }
  func addOnLoadListener(listener: any Callback<onLoadData, Void>) throws -> ListenerSubscription { try sink.addOnLoadListener(listener: listener) }
  func addOnLoadStartListener(listener: any Callback<onLoadStartData, Void>) throws -> ListenerSubscription { try sink.addOnLoadStartListener(listener: listener) }
  func addOnPlaybackStateChangeListener(listener: any Callback<onPlaybackStateChangeData, Void>) throws -> ListenerSubscription { try sink.addOnPlaybackStateChangeListener(listener: listener) }
  func addOnPlaybackRateChangeListener(listener: any Callback<Double, Void>) throws -> ListenerSubscription { try sink.addOnPlaybackRateChangeListener(listener: listener) }
  func addOnProgressListener(listener: any Callback<onProgressData, Void>) throws -> ListenerSubscription { try sink.addOnProgressListener(listener: listener) }
  func addOnReadyToDisplayListener(listener: any Callback<(), Void>) throws -> ListenerSubscription { try sink.addOnReadyToDisplayListener(listener: listener) }
  func addOnSeekListener(listener: any Callback<Double, Void>) throws -> ListenerSubscription { try sink.addOnSeekListener(listener: listener) }
  func addOnStatusChangeListener(listener: any Callback<VideoPlayerStatus, Void>) throws -> ListenerSubscription { try sink.addOnStatusChangeListener(listener: listener) }
  func addOnTimedMetadataListener(listener: any Callback<TimedMetadata, Void>) throws -> ListenerSubscription { try sink.addOnTimedMetadataListener(listener: listener) }
  func addOnTextTrackDataChangedListener(listener: any Callback<[String], Void>) throws -> ListenerSubscription { try sink.addOnTextTrackDataChangedListener(listener: listener) }
  func addOnTrackChangeListener(listener: any Callback<Variant_NullType_TextTrack, Void>) throws -> ListenerSubscription { try sink.addOnTrackChangeListener(listener: listener) }
  func addOnVolumeChangeListener(listener: any Callback<onVolumeChangeData, Void>) throws -> ListenerSubscription { try sink.addOnVolumeChangeListener(listener: listener) }
  func clearAllListeners() throws { try sink.clearAllListeners() }
  func onAudioBecomingNoisy() { sink.onAudioBecomingNoisy() }
  func onAudioFocusChange(_ hasFocus: Bool) { sink.onAudioFocusChange(hasFocus) }
  func onBandwidthUpdate(_ data: BandwidthData) { sink.onBandwidthUpdate(data) }
  func onBuffer(_ isBuffering: Bool) { sink.onBuffer(isBuffering) }
  func onControlsVisibleChange(_ isVisible: Bool) { sink.onControlsVisibleChange(isVisible) }
  func onEnd() { sink.onEnd() }
  func onError(_ error: String) { sink.onError(error) }
  func onExternalPlaybackChange(_ isExternalPlaybackActive: Bool) { sink.onExternalPlaybackChange(isExternalPlaybackActive) }
  func onLoad(_ data: onLoadData) { sink.onLoad(data) }
  func onLoadStart(_ data: onLoadStartData) { sink.onLoadStart(data) }
  func onPlaybackStateChange(_ data: onPlaybackStateChangeData) { sink.onPlaybackStateChange(data) }
  func onPlaybackRateChange(_ rate: Double) { sink.onPlaybackRateChange(rate) }
  func onProgress(_ data: onProgressData) { sink.onProgress(data) }
  func onReadyToDisplay() { sink.onReadyToDisplay() }
  func onSeek(_ position: Double) { sink.onSeek(position) }
  func onStatusChange(_ status: VideoPlayerStatus) { sink.onStatusChange(status) }
  func onTimedMetadata(_ metadata: TimedMetadata) { sink.onTimedMetadata(metadata) }
  func onTextTrackDataChanged(_ tracks: [String]) { sink.onTextTrackDataChanged(tracks) }
  func onTrackChange(_ track: Variant_NullType_TextTrack) { sink.onTrackChange(track) }
  func onVolumeChange(_ data: onVolumeChangeData) { sink.onVolumeChange(data) }
}
