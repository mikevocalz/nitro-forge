import type { ResizeMode } from '../../core/types/ResizeMode';
export * from "#nitro/VideoViewViewManager";
export * from "#nitro/VideoViewViewManagerFactory";
export type SurfaceType = 'surface' | 'texture';
export interface NativeViewOptions {
    readonly controls: boolean;
    readonly pictureInPicture: boolean;
    readonly autoEnterPictureInPicture: boolean;
    readonly resizeMode: ResizeMode;
    readonly keepScreenAwake: boolean;
    readonly surfaceType: SurfaceType;
}
//# sourceMappingURL=VideoViewViewManager.nitro.d.ts.map