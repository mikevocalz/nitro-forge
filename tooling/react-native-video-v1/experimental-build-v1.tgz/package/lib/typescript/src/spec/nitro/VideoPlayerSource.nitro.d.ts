import type { HybridObject } from 'react-native-nitro-modules';
import type { NativeVideoConfig } from '../../core/types/VideoConfig';
import type { VideoInformation } from "../../core/types/VideoInformation";
export * from "#nitro/VideoPlayerSource";
export * from "#nitro/VideoPlayerSourceFactory";
export declare class VideoPlayerSource extends HybridObject {
    readonly uri: string;
    readonly config: NativeVideoConfig;
    getAssetInformationAsync(): Promise<VideoInformation>;
}
export declare class VideoPlayerSourceFactory extends HybridObject {
    constructor();
    fromUri(uri: string): VideoPlayerSource;
    fromVideoConfig(config: NativeVideoConfig): VideoPlayerSource;
}
//# sourceMappingURL=VideoPlayerSource.nitro.d.ts.map