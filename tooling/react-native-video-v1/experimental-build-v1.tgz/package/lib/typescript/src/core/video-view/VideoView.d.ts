import * as React from 'react';
import type { VideoViewProps, VideoViewRef } from './VideoViewProps';
declare const _default: React.NamedExoticComponent<VideoViewProps & React.RefAttributes<VideoViewRef>>;
export default _default;
//# sourceMappingURL=VideoView.d.ts.map