export interface VideoTrack {
    id: string;
    label: string;
    language?: string;
    selected: boolean;
}
//# sourceMappingURL=VideoTrack.d.ts.map