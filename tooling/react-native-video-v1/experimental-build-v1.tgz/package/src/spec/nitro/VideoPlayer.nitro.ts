import type { HybridObject } from 'react-native-nitro-modules';
import { Android, Apple } from "react-native-nitro-modules";
import type { IgnoreSilentSwitchMode } from "../../core/types/IgnoreSilentSwitchMode";
import type { MixAudioMode } from "../../core/types/MixAudioMode";
import type { TextTrack } from '../../core/types/TextTrack';
import type { VideoPlayerStatus } from "../../core/types/VideoPlayerStatus";
import type { VideoPlayerEventEmitter } from './VideoPlayerEventEmitter.nitro';
import type { VideoPlayerSource } from './VideoPlayerSource.nitro';

export * from "#nitro/VideoPlayer";
export * from "#nitro/VideoPlayerFactory";

export interface NativePlayerOptions {
  showNotificationControls?: boolean;
  volume?: number;
  muted?: boolean;
  loop?: boolean;
  rate?: number;
  mixAudioMode?: MixAudioMode;
  ignoreSilentSwitchMode?: IgnoreSilentSwitchMode;
  playInBackground?: boolean;
  playWhenInactive?: boolean;
  disableAudioSessionManagement?: boolean;
}

@Apple({ language: 'swift', implementation: { className: 'HybridVideoPlayer' } })
@Android({ language: 'kotlin', implementation: { className: 'HybridVideoPlayer' } })
export declare class VideoPlayer extends HybridObject {

  readonly source: VideoPlayerSource;
  readonly eventEmitter: VideoPlayerEventEmitter;
  readonly showNotificationControls: boolean;
  configure(options: NativePlayerOptions): Promise<void>;
  replaceSourceAsync(source: VideoPlayerSource | null): Promise<void>;
  getAvailableTextTracks(): TextTrack[];
  selectTextTrack(textTrack: TextTrack | null): Promise<void>;
  release(): void;
  readonly status: VideoPlayerStatus;
  readonly duration: number;
  readonly volume: number;
  readonly currentTime: number;
  readonly muted: boolean;
  readonly loop: boolean;
  readonly rate: number;
  readonly mixAudioMode: MixAudioMode;
  readonly ignoreSilentSwitchMode: IgnoreSilentSwitchMode;
  readonly playInBackground: boolean;
  readonly playWhenInactive: boolean;
  readonly disableAudioSessionManagement: boolean;
  readonly isPlaying: boolean;
  initialize(): Promise<void>;
  preload(): Promise<void>;
  play(): Promise<void>;
  pause(): Promise<void>;
  seekBy(time: number): Promise<void>;
  seekTo(time: number): Promise<void>;
  readonly selectedTrack?: TextTrack;
}

@Apple({ language: 'swift', implementation: { className: 'HybridVideoPlayerFactory' } })
@Android({ language: 'kotlin', implementation: { className: 'HybridVideoPlayerFactory' } })
export declare class VideoPlayerFactory extends HybridObject {
  constructor();
  createPlayer(source: VideoPlayerSource): VideoPlayer;
  setAudioSessionManagementDisabled(disabled: boolean): Promise<void>;
}
