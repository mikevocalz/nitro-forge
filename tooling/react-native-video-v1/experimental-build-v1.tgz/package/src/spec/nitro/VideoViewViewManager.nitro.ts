import type { HybridObject } from 'react-native-nitro-modules';
import { Android, Apple } from "react-native-nitro-modules";
import type { ResizeMode } from '../../core/types/ResizeMode';
import type { VideoPlayer } from './VideoPlayer.nitro';
import type { ListenerSubscription } from './VideoPlayerEventEmitter.nitro';

export * from "#nitro/VideoViewViewManager";
export * from "#nitro/VideoViewViewManagerFactory";

export type SurfaceType = 'surface' | 'texture';

export interface NativeViewOptions {
  readonly controls: boolean;
  readonly pictureInPicture: boolean;
  readonly autoEnterPictureInPicture: boolean;
  readonly resizeMode: ResizeMode;
  readonly keepScreenAwake: boolean;
  readonly surfaceType: SurfaceType;
}

// @internal
@Apple({ language: 'swift', implementation: { className: 'HybridVideoViewViewManager' } })
@Android({ language: 'kotlin', implementation: { className: 'HybridVideoViewViewManager' } })
export declare class VideoViewViewManager extends HybridObject {

  readonly player?: VideoPlayer;
  applyProps(options: NativeViewOptions, player: VideoPlayer | null): Promise<void>;
  readonly controls: boolean;
  readonly pictureInPicture: boolean;
  readonly autoEnterPictureInPicture: boolean;
  readonly resizeMode: ResizeMode;
  enterFullscreen(): Promise<void>;
  exitFullscreen(): Promise<void>;
  enterPictureInPicture(): Promise<void>;
  exitPictureInPicture(): Promise<void>;
  canEnterPictureInPicture(): Promise<boolean>;
  readonly keepScreenAwake: boolean;
  readonly surfaceType: SurfaceType;
  addOnPictureInPictureChangeListener(
    listener: (isInPictureInPicture: boolean) => void
  ): ListenerSubscription;
  addOnFullscreenChangeListener(
    listener: (fullscreen: boolean) => void
  ): ListenerSubscription;
  addWillEnterFullscreenListener(listener: () => void): ListenerSubscription;
  addWillExitFullscreenListener(listener: () => void): ListenerSubscription;
  addWillEnterPictureInPictureListener(
    listener: () => void
  ): ListenerSubscription;
  addWillExitPictureInPictureListener(
    listener: () => void
  ): ListenerSubscription;
  clearAllListeners(): void;
}

// @internal
@Apple({ language: 'swift', implementation: { className: 'HybridVideoViewViewManagerFactory' } })
@Android({ language: 'kotlin', implementation: { className: 'HybridVideoViewViewManagerFactory' } })
export declare class VideoViewViewManagerFactory extends HybridObject {
  constructor();
  createViewManager(nitroId: number): VideoViewViewManager;
}
