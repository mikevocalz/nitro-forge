import type { HybridObject } from 'react-native-nitro-modules';
import { Android, Apple } from "react-native-nitro-modules";
import type { NativeVideoConfig } from '../../core/types/VideoConfig';
import type { VideoInformation } from "../../core/types/VideoInformation";

export * from "#nitro/VideoPlayerSource";
export * from "#nitro/VideoPlayerSourceFactory";

@Apple({ language: 'swift', implementation: { className: 'HybridVideoPlayerSource' } })
@Android({ language: 'kotlin', implementation: { className: 'HybridVideoPlayerSource' } })
export declare class VideoPlayerSource extends HybridObject {

  readonly uri: string;
  readonly config: NativeVideoConfig;
  getAssetInformationAsync(): Promise<VideoInformation>;
}

@Apple({ language: 'swift', implementation: { className: 'HybridVideoPlayerSourceFactory' } })
@Android({ language: 'kotlin', implementation: { className: 'HybridVideoPlayerSourceFactory' } })
export declare class VideoPlayerSourceFactory extends HybridObject {
  constructor();
  fromUri(uri: string): VideoPlayerSource;
  fromVideoConfig(config: NativeVideoConfig): VideoPlayerSource;
}
