import { Platform } from 'react-native';
import { NitroModules } from 'react-native-nitro-modules';
import type { VideoPlayer as VideoPlayerImpl } from '../spec/nitro/VideoPlayer.nitro';
import type { VideoPlayerSource } from '../spec/nitro/VideoPlayerSource.nitro';
import type { IgnoreSilentSwitchMode } from './types/IgnoreSilentSwitchMode';
import type { MixAudioMode } from './types/MixAudioMode';
import type { TextTrack } from './types/TextTrack';
import type { NoAutocomplete } from './types/Utils';
import type { VideoConfig, VideoSource } from './types/VideoConfig';
import {
  tryParseNativeVideoError,
  VideoRuntimeError,
} from './types/VideoError';
import type { VideoPlayerBase } from './types/VideoPlayerBase';
import type { VideoPlayerStatus } from './types/VideoPlayerStatus';
import { createPlayer } from './utils/playerFactory';
import { createSource } from './utils/sourceFactory';
import { VideoPlayerEvents } from './events/VideoPlayerEvents';

class VideoPlayer extends VideoPlayerEvents implements VideoPlayerBase {
  private _player: VideoPlayerImpl | undefined;

  protected get player(): VideoPlayerImpl {
    if (this._player === undefined) {
      throw new VideoRuntimeError(
        'player/released',
        "You can't access player after it's released"
      );
    }

    return this._player;
  }

  constructor(source: VideoSource | VideoConfig | VideoPlayerSource) {
    const hybridSource = createSource(source);
    const player = createPlayer(hybridSource);

    // Initialize events
    super(player.eventEmitter);
    this._player = player;
  }

  /**
   * Releases the player's native resources and releases native state.
   * @internal
   */
  __destroy() {
    const player = this._player;
    if (player === undefined) return;
    // Invalidate synchronously so re-entrant callbacks cannot reuse a released owner.
    this._player = undefined;
    let source: VideoPlayerSource | undefined;
    try { source = player.source; } catch { /* Already released by native teardown. */ }
    try { this.clearAllEvents(); } catch (error) {
      console.warn('Failed to clear native player listeners', error);
    }
    try { player.release(); } catch (error) {
      console.warn('Failed to release native player', error);
    }
    try {
      NitroModules.updateMemorySize(player);
      if (source) NitroModules.updateMemorySize(source);
    } catch (error) {
      console.warn('Failed to update released player memory accounting', error);
    }
  }

  /**
   * Returns the native (hybrid) player instance.
   * Should not be used outside of the module.
   * @internal
   */
  __isReleased(): boolean { return this._player === undefined; }

  __getNativePlayer() {
    return this.player;
  }

  /**
   * Handles parsing native errors to VideoRuntimeError and calling onError if provided
   * @internal
   */
  private throwError(error: unknown) {
    const parsedError = tryParseNativeVideoError(error);

    if (
      parsedError instanceof VideoRuntimeError &&
      this.triggerJSEvent('onError', parsedError as VideoRuntimeError)
    ) {
      // We don't throw errors if onError is provided
      return;
    }

    throw parsedError;
  }

  /**
   * Updates the memory size of the player and its source. Should be called after any operation that changes the memory size of the player or its source.
   * @internal
   */
  private updateMemorySize() {
    NitroModules.updateMemorySize(this.player);
    NitroModules.updateMemorySize(this.player.source);
  }

  /**
   * Wraps a promise to try parsing native errors to VideoRuntimeError
   * @internal
   */
  private async wrapPromise<T>(promise: Promise<T>): Promise<T> {
    try {
      return await promise;
    } catch (error) {
      const parsed = tryParseNativeVideoError(error);
      if (parsed instanceof VideoRuntimeError) this.triggerJSEvent('onError', parsed);
      throw parsed;
    }
  }

  /** Await native application of options; getters contain the latest native snapshot. */
  async configure(options: import('../spec/nitro/VideoPlayer.nitro').NativePlayerOptions): Promise<void> {
    await this.wrapPromise(this.player.configure(options));
  }

  private submit(promise: Promise<void>): void {
    void this.wrapPromise(promise).catch(error => console.error('[react-native-video]', error));
  }

  // Source
  get source(): VideoPlayerSource {
    return this.player.source;
  }

  // Status
  get status(): VideoPlayerStatus {
    return this.player.status;
  }

  // Duration
  get duration(): number {
    return this.player.duration;
  }

  // Volume
  get volume(): number {
    return this.player.volume;
  }

  set volume(value: number) {
    this.submit(this.player.configure({ volume: value }));
  }

  // Current Time
  get currentTime(): number {
    return this.player.currentTime;
  }

  set currentTime(value: number) {
    this.submit(this.player.seekTo(value));
  }

  // Muted
  get muted(): boolean {
    return this.player.muted;
  }

  set muted(value: boolean) {
    this.submit(this.player.configure({ muted: value }));
  }

  // Loop
  get loop(): boolean {
    return this.player.loop;
  }

  set loop(value: boolean) {
    this.submit(this.player.configure({ loop: value }));
  }

  // Rate
  get rate(): number {
    return this.player.rate;
  }

  set rate(value: number) {
    this.submit(this.player.configure({ rate: value }));
  }

  // Mix Audio Mode
  get mixAudioMode(): MixAudioMode {
    return this.player.mixAudioMode;
  }

  set mixAudioMode(value: MixAudioMode) {
    this.submit(this.player.configure({ mixAudioMode: value }));
  }

  // Ignore Silent Switch Mode
  get ignoreSilentSwitchMode(): IgnoreSilentSwitchMode {
    return this.player.ignoreSilentSwitchMode;
  }

  set ignoreSilentSwitchMode(value: IgnoreSilentSwitchMode) {
    if (__DEV__ && !['ios'].includes(Platform.OS)) {
      console.warn(
        'ignoreSilentSwitchMode is not supported on this platform, it wont have any effect'
      );
    }

    this.submit(this.player.configure({ ignoreSilentSwitchMode: value }));
  }

  // Play In Background
  get playInBackground(): boolean {
    return this.player.playInBackground;
  }

  set playInBackground(value: boolean) {
    this.submit(this.player.configure({ playInBackground: value }));
  }

  // Play When Inactive
  get playWhenInactive(): boolean {
    return this.player.playWhenInactive;
  }

  set playWhenInactive(value: boolean) {
    this.submit(this.player.configure({ playWhenInactive: value }));
  }

  // Disable Audio Session Management
  get disableAudioSessionManagement(): boolean {
    return this.player.disableAudioSessionManagement;
  }

  set disableAudioSessionManagement(value: boolean) {
    if (__DEV__ && !['ios'].includes(Platform.OS)) {
      console.warn(
        'disableAudioSessionManagement is not supported on this platform, it wont have any effect'
      );
    }

    this.submit(this.player.configure({ disableAudioSessionManagement: value }));
  }

  // Is Playing
  get isPlaying(): boolean {
    return this.player.isPlaying;
  }

  get showNotificationControls(): boolean {
    return this.player.showNotificationControls;
  }

  set showNotificationControls(value: boolean) {
    this.submit(this.player.configure({ showNotificationControls: value }));
  }

  async initialize(): Promise<void> {
    await this.wrapPromise(this.player.initialize());

    this.updateMemorySize();
  }

  async preload(): Promise<void> {
    await this.wrapPromise(this.player.preload());

    this.updateMemorySize();
  }

  /**
   * Releases the player's native resources and releases native state.
   * After calling this method, the player is no longer usable.
   * Accessing any properties or methods of the player after calling this method will throw an error.
   * If you want to clean player resource use `replaceSourceAsync` with `null` instead.
   */
  release(): void {
    this.__destroy();
  }

  play(): Promise<void> {
    return this.wrapPromise(this.player.play());
  }

  pause(): Promise<void> {
    return this.wrapPromise(this.player.pause());
  }

  seekBy(time: number): Promise<void> {
    return this.wrapPromise(this.player.seekBy(time));
  }

  seekTo(time: number): Promise<void> {
    return this.wrapPromise(this.player.seekTo(time));
  }

  async replaceSourceAsync(
    source: VideoSource | VideoConfig | NoAutocomplete<VideoPlayerSource> | null
  ): Promise<void> {
    this.updateMemorySize();

    await this.wrapPromise(
      this.player.replaceSourceAsync(
        source === null ? null : createSource(source)
      )
    );

    this.updateMemorySize();
  }

  // Text Track Management
  getAvailableTextTracks(): TextTrack[] {
    try {
      return this.player.getAvailableTextTracks();
    } catch (error) {
      this.throwError(error);
      return [];
    }
  }

  selectTextTrack(textTrack: TextTrack | null): Promise<void> {
    return this.wrapPromise(this.player.selectTextTrack(textTrack));
  }

  // Selected Text Track
  get selectedTrack(): TextTrack | undefined {
    return this.player.selectedTrack;
  }
}

export { VideoPlayer };
