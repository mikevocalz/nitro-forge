import {
  forwardRef,
  memo,
  useCallback,
  useEffect,
  useImperativeHandle,
  useRef,
  type CSSProperties,
} from 'react';
import { View } from 'react-native';
import type { VideoPlayer } from '../VideoPlayer.web';
import type { VideoViewEvents } from '../types/Events';
import type { ListenerSubscription } from '../types/EventEmitter';
import type { VideoViewProps, VideoViewRef } from './VideoViewProps';
import {
  createPlayer,
  videoFeatures,
  usePlayerContext,
  useMediaAttach,
} from '@videojs/react';
import { VideoSkin } from '@videojs/react/video';
import '@videojs/react/video/skin.css';
import type { VideoStore } from '../web/VideoStore';
import { useViewEvents, addViewEventListener } from './useViewEvents.web';

const Player = createPlayer({ features: videoFeatures });

const OBJECT_FIT_MAP: Record<string, CSSProperties['objectFit']> = {
  contain: 'contain',
  cover: 'cover',
  stretch: 'fill',
  none: 'contain',
};

function PlayerBridge({ player }: { player: VideoPlayer }) {
  const { store: rawStore, container } = usePlayerContext();
  const store = rawStore as unknown as VideoStore;
  const setMedia = useMediaAttach();

  useEffect(() => {
    if (!container) return;

    const video = player.__getMedia();
    setMedia?.(video);
    const detach = store.attach({ media: video, container });
    player.__setStore(store);

    return () => {
      player.__setStore(null);
      try {
        detach?.();
      } catch {
        /* store may already be destroyed by Provider */
      }
      setMedia?.(null);
    };
  }, [store, player, setMedia, container]);

  return null;
}

function VideoElement({
  player,
  objectFit,
}: {
  player: VideoPlayer;
  objectFit: string;
}) {
  const mountRef = useCallback(
    (container: HTMLDivElement | null) => {
      if (!container) return;
      const video = player.__getMedia();
      Object.assign(video.style, { width: '100%', height: '100%', objectFit });
      if (video.parentNode !== container) {
        container.appendChild(video);
      }
    },
    [player, objectFit]
  );

  return <div ref={mountRef} style={{ width: '100%', height: '100%' }} />;
}

const VideoView = forwardRef<VideoViewRef, VideoViewProps>(
  (
    {
      player: nPlayer,
      controls = false,
      resizeMode = 'none',
      onFullscreenChange,
      onPictureInPictureChange,
      willEnterFullscreen,
      willExitFullscreen,
      willEnterPictureInPicture,
      willExitPictureInPicture,
      pictureInPicture: _pip = false,
      autoEnterPictureInPicture: _autoPip = false,
      keepScreenAwake: _keepAwake = true,
      ...props
    },
    ref
  ) => {
    const player = nPlayer as unknown as VideoPlayer;
    const containerRef = useRef<HTMLDivElement>(null);
    const objectFit = OBJECT_FIT_MAP[resizeMode] ?? 'contain';

    useViewEvents(player, containerRef, {
      onFullscreenChange,
      onPictureInPictureChange,
      willEnterFullscreen,
      willExitFullscreen,
      willEnterPictureInPicture,
      willExitPictureInPicture,
    });

    useImperativeHandle(
      ref,
      () => ({
        enterFullscreen: async () => {
          await containerRef.current?.requestFullscreen?.();
        },
        exitFullscreen: async () => {
          await document.exitFullscreen?.();
        },
        enterPictureInPicture: async () => {
          await player.__getMedia()?.requestPictureInPicture?.();
        },
        exitPictureInPicture: async () => {
          await document.exitPictureInPicture?.();
        },
        canEnterPictureInPicture: async () =>
          document.pictureInPictureEnabled ?? false,
        addEventListener: <Event extends keyof VideoViewEvents>(
          event: Event,
          callback: VideoViewEvents[Event]
        ): ListenerSubscription =>
          addViewEventListener(player, event, callback),
      }),
      [player]
    );

    const videoContent = <VideoElement player={player} objectFit={objectFit} />;

    return (
      <View {...props}>
        <Player.Provider>
          <PlayerBridge player={player} />
          <Player.Container
            ref={containerRef}
            style={
              {
                'position': 'absolute',
                'inset': '0',
                'width': '100%',
                'height': '100%',
                '--media-border-radius': '0',
              } as CSSProperties
            }
          >
            {controls ? <VideoSkin>{videoContent}</VideoSkin> : videoContent}
          </Player.Container>
        </Player.Provider>
      </View>
    );
  }
);

VideoView.displayName = 'VideoView';

export default memo(VideoView);
