import { createStore } from 'zustand/vanilla';
import { useStore } from 'zustand';
import { VideoViewViewManagerFactory as NativeVideoViewViewManagerFactory } from '../../spec/nitro/VideoViewViewManager.nitro';
import * as React from 'react';
import type { ListenerSubscription } from '../../spec/nitro/VideoPlayerEventEmitter.nitro';
import type {
  VideoViewViewManager,
} from '../../spec/nitro/VideoViewViewManager.nitro';
import { type VideoViewEvents } from '../types/Events';
import {
  tryParseNativeVideoError,
  VideoComponentError,
  VideoError,
} from '../types/VideoError';
import type { VideoPlayer } from '../VideoPlayer';
import { NativeVideoView } from './NativeVideoView';
import type { VideoViewProps, VideoViewRef } from './VideoViewProps';

let nitroIdCounter = 1;
const VideoViewViewManagerFactory = new NativeVideoViewViewManagerFactory();

const wrapNativeViewManagerFunction = <T,>(
  manager: VideoViewViewManager | null,
  func: (manager: VideoViewViewManager) => T
) => {
  try {
    if (manager === null) {
      throw new VideoError('view/not-found', 'View manager not found');
    }

    return func(manager);
  } catch (error) {
    throw tryParseNativeVideoError(error);
  }
};

const updateProps = (manager: VideoViewViewManager, props: VideoViewProps) => {
  const player = props.player as VideoPlayer;
  return manager.applyProps({
    controls: props.controls ?? false,
    pictureInPicture: props.pictureInPicture ?? false,
    autoEnterPictureInPicture: props.autoEnterPictureInPicture ?? false,
    resizeMode: props.resizeMode ?? 'none',
    keepScreenAwake: props.keepScreenAwake ?? true,
    surfaceType: props.surfaceType ?? 'surface',
  }, player.__isReleased() ? null : player.__getNativePlayer());
};

/**
 * VideoView is a component that allows you to display a video from a {@link VideoPlayer}.
 *
 * @param player - The player to play the video - {@link VideoPlayer}
 * @param controls - Whether to show the controls. Defaults to false.
 * @param style - The style of the video view - {@link ViewStyle}
 * @param pictureInPicture - Whether to show the picture in picture button. Defaults to false.
 * @param autoEnterPictureInPicture - Whether to automatically enter picture in picture mode
 * when the video is playing. Defaults to false.
 * @param resizeMode - How the video should be resized to fit the view. Defaults to 'none'.
 */
const VideoView = React.forwardRef<VideoViewRef, VideoViewProps>(
  (
    {
      player,
      controls = false,
      pictureInPicture = false,
      autoEnterPictureInPicture = false,
      resizeMode = 'none',
      onPictureInPictureChange,
      onFullscreenChange,
      willEnterFullscreen,
      willExitFullscreen,
      willEnterPictureInPicture,
      willExitPictureInPicture,
      ...props
    },
    ref
  ) => {
    const nitroId = React.useMemo(() => nitroIdCounter++, []);
    const nitroViewManager = React.useRef<VideoViewViewManager | null>(null);
    const generationStore = React.useMemo(() => createStore(() => ({ generation: 0 })), []);
    const managerGeneration = useStore(generationStore, state => state.generation);

    const setupViewManager = React.useCallback(
      (id: number) => {
        try {
          nitroViewManager.current =
            VideoViewViewManagerFactory.createViewManager(id);

          // Should never happen
          if (!nitroViewManager.current) {
            throw new VideoError(
              'view/not-found',
              'Failed to create View Manager'
            );
          }

          generationStore.setState(state => ({ generation: state.generation + 1 }));
        } catch (error) {
          const parsedError = tryParseNativeVideoError(error);

          if (
            parsedError instanceof VideoComponentError &&
            parsedError.code === 'view/not-found'
          ) {
            // The view was not found, did view get unmounted?
            if (id === nitroId) {
              // The id from native is same as the one we have,
              // so the view was unmounted before native manager was able to find it

              // On slow devices, when we quickly mount and unmount the view,
              // the native manager may not have been able to find the view before the view was unmounted
              // This should really never happen, but it's better to be safe than sorry

              // We don't throw an error here, because it's not an actual error.
              console.warn(
                '[ReactNativeVideo] VideoView was unmounted before native manager was able to find it. It can happen when the view is quickly mounted and unmounted.'
              );

              return;
            }
          }

          throw parsedError;
        }
      },
      [nitroId]
    );

    const onNitroIdChange = React.useCallback(
      (event: { nativeEvent: { nitroId: number } }) => {
        setupViewManager(event.nativeEvent.nitroId);
      },
      [setupViewManager]
    );

    React.useImperativeHandle(
      ref,
      () => ({
        enterFullscreen: () => {
          return wrapNativeViewManagerFunction(nitroViewManager.current, (manager) => {
            return manager.enterFullscreen();
          });
        },
        exitFullscreen: () => {
          return wrapNativeViewManagerFunction(nitroViewManager.current, (manager) => {
            return manager.exitFullscreen();
          });
        },
        enterPictureInPicture: () => {
          return wrapNativeViewManagerFunction(nitroViewManager.current, (manager) => {
            return manager.enterPictureInPicture();
          });
        },
        exitPictureInPicture: () => {
          return wrapNativeViewManagerFunction(nitroViewManager.current, (manager) => {
            return manager.exitPictureInPicture();
          });
        },
        canEnterPictureInPicture: () => {
          return wrapNativeViewManagerFunction(
            nitroViewManager.current,
            (manager) => {
              return manager.canEnterPictureInPicture();
            }
          );
        },
        addEventListener: <Event extends keyof VideoViewEvents>(
          event: Event,
          callback: VideoViewEvents[Event]
        ): ListenerSubscription => {
          return wrapNativeViewManagerFunction(
            nitroViewManager.current,
            (manager) => {
              switch (event) {
                case 'onPictureInPictureChange':
                  return manager.addOnPictureInPictureChangeListener(
                    callback as VideoViewEvents['onPictureInPictureChange']
                  );
                case 'onFullscreenChange':
                  return manager.addOnFullscreenChangeListener(
                    callback as VideoViewEvents['onFullscreenChange']
                  );
                case 'willEnterFullscreen':
                  return manager.addWillEnterFullscreenListener(
                    callback as VideoViewEvents['willEnterFullscreen']
                  );
                case 'willExitFullscreen':
                  return manager.addWillExitFullscreenListener(
                    callback as VideoViewEvents['willExitFullscreen']
                  );
                case 'willEnterPictureInPicture':
                  return manager.addWillEnterPictureInPictureListener(
                    callback as VideoViewEvents['willEnterPictureInPicture']
                  );
                case 'willExitPictureInPicture':
                  return manager.addWillExitPictureInPictureListener(
                    callback as VideoViewEvents['willExitPictureInPicture']
                  );
                default:
                  throw new Error(
                    `[React Native Video] Unsupported event: ${event}`
                  );
              }
            }
          );
        },
      }),
      []
    );

    // Cleanup all listeners on unmount
    React.useEffect(() => {
      return () => {
        if (nitroViewManager.current) {
          nitroViewManager.current.clearAllListeners();
          generationStore.setState({ generation: 0 });
        }
      };
    }, []);

    // Register prop-based event callbacks as listeners
    React.useEffect(() => {
      if (!nitroViewManager.current) {
        return;
      }

      const subscriptions: ListenerSubscription[] = [];

      if (onPictureInPictureChange) {
        subscriptions.push(
          nitroViewManager.current.addOnPictureInPictureChangeListener(
            onPictureInPictureChange
          )
        );
      }
      if (onFullscreenChange) {
        subscriptions.push(
          nitroViewManager.current.addOnFullscreenChangeListener(
            onFullscreenChange
          )
        );
      }
      if (willEnterFullscreen) {
        subscriptions.push(
          nitroViewManager.current.addWillEnterFullscreenListener(
            willEnterFullscreen
          )
        );
      }
      if (willExitFullscreen) {
        subscriptions.push(
          nitroViewManager.current.addWillExitFullscreenListener(
            willExitFullscreen
          )
        );
      }
      if (willEnterPictureInPicture) {
        subscriptions.push(
          nitroViewManager.current.addWillEnterPictureInPictureListener(
            willEnterPictureInPicture
          )
        );
      }
      if (willExitPictureInPicture) {
        subscriptions.push(
          nitroViewManager.current.addWillExitPictureInPictureListener(
            willExitPictureInPicture
          )
        );
      }

      return () => {
        subscriptions.forEach((sub) => sub.remove());
      };
    }, [
      onPictureInPictureChange,
      onFullscreenChange,
      willEnterFullscreen,
      willExitFullscreen,
      willEnterPictureInPicture,
      willExitPictureInPicture,
      managerGeneration,
    ]);

    // Update non-event props
    React.useEffect(() => {
      if (!nitroViewManager.current) {
        return;
      }

      // Updates props to native view
      void updateProps(nitroViewManager.current, {
        ...props,
        player: player,
        controls: controls,
        pictureInPicture: pictureInPicture,
        autoEnterPictureInPicture: autoEnterPictureInPicture,
        resizeMode: resizeMode,
      }).catch(error => console.error(tryParseNativeVideoError(error)));
    }, [
      player,
      controls,
      pictureInPicture,
      autoEnterPictureInPicture,
      resizeMode,
      props,
      managerGeneration,
    ]);

    return (
      <NativeVideoView
        nitroId={nitroId}
        onNitroIdChange={onNitroIdChange}
        {...props}
      />
    );
  }
);

VideoView.displayName = 'VideoView';

export default React.memo(VideoView);
