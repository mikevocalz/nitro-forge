//
//  HybridVideoViewViewManagerFactory.swift
//  ReactNativeVideo
//
//  Created by Krzysztof Moch on 23/09/2024.
//

import Foundation

class HybridVideoViewViewManagerFactory: HybridVideoViewViewManagerFactorySpec {
  required override init() throws {
    try super.init()
  }

  func createViewManager(nitroId: Double) throws -> any HybridVideoViewViewManagerSpec {
    return try HybridVideoViewViewManager(nitroId: nitroId)
  }
}
