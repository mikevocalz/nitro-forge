//
//  HybridVideoPlayer+Events.swift
//  ReactNativeVideo
//
//  Created by Krzysztof Moch on 02/05/2025.
//

import AVFoundation
import Foundation

extension HybridVideoPlayer: VideoPlayerObserverDelegate {
  // MARK: - VideoPlayerObserverDelegate

  func onPlayedToEnd(player: AVPlayer) {
    _eventEmitter?.onEnd()

    // Finished — don't resume it on return.
    wasPlayingInBackground = false

    if loop {
      currentTime = 0
      try? play()
    }
  }

  func onRateChanged(rate: Float, reason: AVPlayer.RateDidChangeReason?) {
    _eventEmitter?.onPlaybackRateChange(Double(rate))
    NowPlayingInfoCenterManager.shared.updatePlaybackState()
    updateAndEmitPlaybackState()

    // A deliberate pause (PiP controls, app UI, lock screen) reports .setRateCalled; a system
    // background pause reports .appBackgrounded. Only the former cancels the background-resume
    // intent, so a video paused inside PiP isn't auto-resumed on return.
    if rate == 0, reason == .setRateCalled {
      wasPlayingInBackground = false
    }
  }

  func onVolumeChanged(volume: Float) {
    _eventEmitter?.onVolumeChange(
      onVolumeChangeData(
        volume: Double(volume),
        muted: muted
      )
    )
  }

  /// A failed item can still fire buffer callbacks. They must not move the status out of
  /// `.error`, or the next failure callback would report the same failure again.
  private var hasFailed: Bool {
    player.status == .failed || playerItem?.status == .failed
  }

  func onPlaybackBufferEmpty() {
    guard !hasFailed else { return }
    isCurrentlyBuffering = true
    status = .loading
    updateAndEmitPlaybackState()
  }

  func onProgressUpdate(currentTime: Double, bufferDuration: Double) {
    _eventEmitter?.onProgress(
      .init(currentTime: currentTime, bufferDuration: bufferDuration)
    )
  }

  func onPlaybackLikelyToKeepUp() {
    guard !hasFailed else { return }
    isCurrentlyBuffering = false
    if player.timeControlStatus != .waitingToPlayAtSpecifiedRate {
      status = .readytoplay
    }
    updateAndEmitPlaybackState()
  }

  func onExternalPlaybackActiveChanged(isActive: Bool) {
    _eventEmitter?.onExternalPlaybackChange(isActive)
  }

  func onTimeControlStatusChanged(status: AVPlayer.TimeControlStatus) {
    if player.status == .failed || playerItem?.status == .failed {
      reportAsyncError(playerItem?.error ?? player.error)
      isCurrentlyBuffering = false
      _eventEmitter?.onPlaybackStateChange(
        .init(isPlaying: false, isBuffering: false)
      )
      return
    }

    switch status {
    case .waitingToPlayAtSpecifiedRate:
      isCurrentlyBuffering = true
      self.status = .loading
      break

    case .playing:
      isCurrentlyBuffering = false
      self.status = .readytoplay
      break

    case .paused:
      isCurrentlyBuffering = false
      self.status = .readytoplay
      break

    @unknown default:
      break
    }

    updateAndEmitPlaybackState()

    // Keep the audio session in sync with playback: starting/stopping changes whether we hold
    // the session and the mix mode (mix-with-others vs interrupt), which is otherwise only
    // recomputed on prop/lifecycle changes — not on play/pause.
    VideoManager.shared.requestAudioSessionUpdate()
  }

  func onPlayerStatusChanged(status: AVPlayer.Status) {
    if status == .failed || playerItem?.status == .failed {
      reportAsyncError(playerItem?.error ?? player.error)
      isCurrentlyBuffering = false
      updateAndEmitPlaybackState()
    }
  }

  func onPlayerItemStatusChanged(status: AVPlayerItem.Status) {
    if status == .failed {
      reportAsyncError(playerItem?.error ?? player.error)
      isCurrentlyBuffering = false
      updateAndEmitPlaybackState()
      return
    }

    switch status {
    case .unknown:
      isCurrentlyBuffering = true
      self.status = .loading

      // Set initial buffering state when we have a playerItem
      if let playerItem = self.playerItem {
        if playerItem.isPlaybackBufferEmpty {
          isCurrentlyBuffering = true
        }
      }

    case .readyToPlay:
      guard let playerItem else { return }

      let height = playerItem.presentationSize.height
      let width = playerItem.presentationSize.width
      let orientation: VideoOrientation =
        playerItem.asset.tracks.first(where: { $0.mediaType == .video })?
        .orientation ?? .unknown

      _eventEmitter?.onLoad(
        .init(currentTime: currentTime, duration: duration, height: height, width: width, orientation: orientation)
      )

      if playerItem.isPlaybackLikelyToKeepUp
        && !playerItem.isPlaybackBufferEmpty
      {
        isCurrentlyBuffering = false
        self.status = .readytoplay
      }

    case .failed:
      reportAsyncError(playerItem?.error ?? player.error)
      isCurrentlyBuffering = false

    @unknown default:
      break
    }

    updateAndEmitPlaybackState()
  }

  func onTextTrackDataChanged(texts: [NSAttributedString]) {
    _eventEmitter?.onTextTrackDataChanged(texts.map { $0.string })
  }

  func onTimedMetadataChanged(timedMetadata: [AVMetadataItem]) {
    var metadata: [TimedMetadataObject] = []
    for item in timedMetadata {
      let value = item.value as? String
      let identifier = item.identifier?.rawValue

      if let value, let identifier {
        metadata.append(.init(value: value, identifier: identifier))
      }
    }

    _eventEmitter?.onTimedMetadata(.init(metadata: metadata))
  }

  func onBandwidthUpdate(bitrate: Double) {
    _eventEmitter?.onBandwidthUpdate(
      .init(bitrate: bitrate, width: nil, height: nil)
    )
  }

  func onPlayerItemChange(player _: AVPlayer, playerItem: AVPlayerItem?) {
    guard showNotificationControls, let playerItem else { return }
    DispatchQueue.main.async {
      NowPlayingInfoCenterManager.shared.updateStaticInfo(ifCurrentItem: playerItem)
    }
  }

  func onPlayerItemWillChange(hasNewPlayerItem: Bool) {
    if hasNewPlayerItem {
      // Set initial buffering state when playerItem is assigned
      isCurrentlyBuffering = true
      status = .loading
      updateAndEmitPlaybackState()
    } else {
      // Clean up state when playerItem is cleared
      isCurrentlyBuffering = false
    }
  }

  func updateAndEmitPlaybackState() {
    let isPlaying = player.rate > 0 && !isCurrentlyBuffering

    _eventEmitter?.onPlaybackStateChange(
      .init(isPlaying: isPlaying, isBuffering: isCurrentlyBuffering)
    )
    _eventEmitter?.onBuffer(isCurrentlyBuffering)
  }
}
