//
//  HybridVideoPlayerFactory.swift
//  ReactNativeVideo
//
//  Created by Krzysztof Moch on 09/10/2024.
//

import Foundation
import NitroModules

class HybridVideoPlayerFactory: HybridVideoPlayerFactorySpec {
  required override init() throws {
    try super.init()
  }

  func createPlayer(source: HybridVideoPlayerSourceSpec) throws -> HybridVideoPlayerSpec {
    return try HybridVideoPlayer(source: source)
  }

  func setAudioSessionManagementDisabled(disabled: Bool) throws {
    VideoManager.shared.setAudioSessionManagementDisabled(disabled)
  }
}
