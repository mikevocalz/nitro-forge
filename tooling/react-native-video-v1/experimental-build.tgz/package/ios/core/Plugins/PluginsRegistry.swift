//
//  PluginRegistry.swift
//  ReactNativeVideo
//
//  Created by Krzysztof Moch on 22/07/2025.
//

import AVFoundation
import Foundation

// Only registry membership is shared: every dictionary access is protected by `lock`.
// Plugin callbacks and property getters run outside the lock, since they may re-enter
// the registry. Plugin implementations remain responsible for their own mutable state.
// This does not make plugin objects Sendable; do not add an unchecked conformance to
// silence the singleton diagnostic before establishing plugin callback isolation.
public final class PluginsRegistry {
  public static let shared = PluginsRegistry()

  private let lock = NSLock()

  // Plugin ID -> ReactNativeVideoPluginSpec; access only inside withLock.
  private var plugins: [String: ReactNativeVideoPluginSpec] = [:]

  // MARK: - Public API

  public func register(plugin: ReactNativeVideoPluginSpec) {
    // Read user-defined getters before locking; even `id` may re-enter the registry.
    let id = plugin.id
    let previous = withLock { plugins.updateValue(plugin, forKey: id) }

    #if DEBUG
      if previous != nil {
        print(
          "[ReactNativeVideo] Plugin \(plugin.name) (ID: \(id)) is already registered - overwriting."
        )
      } else {
        print(
          "[ReactNativeVideo] Registering plugin \(plugin.name) (ID: \(id))."
        )
      }
    #endif

    // A replaced plugin's deinit can unregister another plugin. Release it unlocked.
    withExtendedLifetime(previous) {}
  }

  public func unregister(plugin: ReactNativeVideoPluginSpec) {
    let id = plugin.id
    let removed = withLock { plugins.removeValue(forKey: id) }

    #if DEBUG
      if removed == nil {
        print(
          "[ReactNativeVideo] Plugin \(plugin.name) (ID: \(id)) is not registered - skipping."
        )
      } else {
        print("[ReactNativeVideo] Unregistering plugin \(plugin.name) (ID: \(id)).")
      }
    #endif

    withExtendedLifetime(removed) {}
  }

  // MARK: - Internal API

  private func withLock<T>(_ operation: () -> T) -> T {
    lock.lock()
    defer { lock.unlock() }
    return operation()
  }

  private func snapshot() -> [ReactNativeVideoPluginSpec] {
    withLock { Array(plugins.values) }
  }

  internal func getDrmManager(source: NativeVideoPlayerSource) throws -> DRMManagerSpec? {
    for plugin in snapshot() {
      if let drmManager = plugin.getDRMManager(source: source) {
        return drmManager
      }
    }

    throw LibraryError.DRMPluginNotFound.error()
  }

  internal func overrideSource(source: NativeVideoPlayerSource) async
    -> NativeVideoPlayerSource
  {
    var overriddenSource = source

    for plugin in snapshot() {
      overriddenSource = await plugin.overrideSource(source: overriddenSource)
    }

    return overriddenSource
  }

  // MARK: - Notifications

  internal func notifyPlayerCreated(player: NativeVideoPlayer) {
    for plugin in snapshot() {
      plugin.onPlayerCreated(player: Weak(value: player))
    }
  }

  internal func notifyPlayerDestroyed(player: NativeVideoPlayer) {
    for plugin in snapshot() {
      plugin.onPlayerDestroyed(player: Weak(value: player))
    }
  }

  internal func notifyVideoViewCreated(view: VideoComponentView) {
    for plugin in snapshot() {
      plugin.onVideoViewCreated(view: Weak(value: view))
    }
  }

  internal func notifyVideoViewDestroyed(view: VideoComponentView) {
    for plugin in snapshot() {
      plugin.onVideoViewDestroyed(view: Weak(value: view))
    }
  }
}
