require "json"
package = JSON.parse(File.read(File.join(__dir__, "package.json")))

# Discovery-only, matching Nitro v1's own podspec. Native code is built through
# React Native's SwiftPM integration and Package.swift, not CocoaPods sources.
Pod::Spec.new do |s|
  s.name = "ReactNativeVideo"
  s.version = package["version"]
  s.summary = package["description"]
  s.homepage = package["homepage"]
  s.license = package["license"]
  s.authors = package["author"]
  s.source = { :git => "https://github.com/TheWidlarzGroup/react-native-video.git", :tag => "v7.0.0-beta.12" }
  s.ios.deployment_target = "16.0"
end
