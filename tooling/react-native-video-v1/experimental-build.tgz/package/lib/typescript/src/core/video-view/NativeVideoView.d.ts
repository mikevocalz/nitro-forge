export declare const NativeVideoView: import("react-native").HostComponent<import("../../spec/fabric/VideoViewNativeComponent").ViewViewNativeProps>;
//# sourceMappingURL=NativeVideoView.d.ts.map