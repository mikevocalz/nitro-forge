export interface AudioTrack {
    id: string;
    label: string;
    language?: string;
    selected: boolean;
}
//# sourceMappingURL=AudioTrack.d.ts.map