/**
 * Disables the internal audio session management on iOS.
 * When disabled, react-native-video will not configure or activate the AVAudioSession,
 * allowing other libraries (like audio recording libraries) to manage it.
 *
 * @param disabled - If true, audio session management is disabled
 * @platform iOS
 *
 * @example
 * ```tsx
 * // Disable audio session management before recording
 * setAudioSessionManagementDisabled(true);
 *
 * // Record audio using another library...
 *
 * // Re-enable audio session management after recording
 * setAudioSessionManagementDisabled(false);
 * ```
 */
export declare const setAudioSessionManagementDisabled: (disabled: boolean) => void;
//# sourceMappingURL=playerFactory.d.ts.map