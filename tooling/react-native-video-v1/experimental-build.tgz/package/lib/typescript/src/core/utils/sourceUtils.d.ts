import { VideoPlayerSource } from '../../spec/nitro/VideoPlayerSource.nitro';
export declare const isVideoPlayerSource: (obj: unknown) => obj is VideoPlayerSource;
//# sourceMappingURL=sourceUtils.d.ts.map