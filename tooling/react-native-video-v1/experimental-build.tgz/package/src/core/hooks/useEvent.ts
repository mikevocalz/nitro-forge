import { useEffect } from 'react';
import type { AllPlayerEvents } from '../types/Events';
import type { VideoPlayerBase } from '../types/VideoPlayerBase';

/**
 * Attaches an event listener to a `VideoPlayer` instance for a specified event.
 *
 * @param player - The player to attach the event to
 * @param event - The name of the event to attach the callback to
 * @param callback - The callback for the event
 */
export const useEvent = <T extends keyof AllPlayerEvents>(
  player: VideoPlayerBase,
  event: T,
  callback: AllPlayerEvents[T]
) => {
  useEffect(() => {
    const subscription = player.addEventListener(event, callback);

    return () => {
      subscription.remove();
    };
  }, [player, event, callback]);
};
