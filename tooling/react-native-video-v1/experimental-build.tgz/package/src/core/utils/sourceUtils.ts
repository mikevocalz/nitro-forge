import { VideoPlayerSource } from '../../spec/nitro/VideoPlayerSource.nitro';

export const isVideoPlayerSource = (obj: unknown): obj is VideoPlayerSource => {
  return obj instanceof VideoPlayerSource;
};
