import type { HybridObject } from 'react-native-nitro-modules';
import { Android, Apple } from "react-native-nitro-modules";
import type { IgnoreSilentSwitchMode } from "../../core/types/IgnoreSilentSwitchMode";
import type { MixAudioMode } from "../../core/types/MixAudioMode";
import type { TextTrack } from '../../core/types/TextTrack';
import type { VideoPlayerStatus } from "../../core/types/VideoPlayerStatus";
import type { VideoPlayerEventEmitter } from './VideoPlayerEventEmitter.nitro';
import type { VideoPlayerSource } from './VideoPlayerSource.nitro';

export * from "#nitro/VideoPlayer";
export * from "#nitro/VideoPlayerFactory";

@Apple({ language: 'swift', implementation: { className: 'HybridVideoPlayer' } })
@Android({ language: 'kotlin', implementation: { className: 'HybridVideoPlayer' } })
export declare class VideoPlayer extends HybridObject {

  readonly source: VideoPlayerSource;
  readonly eventEmitter: VideoPlayerEventEmitter;
  showNotificationControls: boolean;
  replaceSourceAsync(source: VideoPlayerSource | null): Promise<void>;
  getAvailableTextTracks(): TextTrack[];
  selectTextTrack(textTrack: TextTrack | null): void;
  release(): void;
  readonly status: VideoPlayerStatus;
  readonly duration: number;
  volume: number;
  currentTime: number;
  muted: boolean;
  loop: boolean;
  rate: number;
  mixAudioMode: MixAudioMode;
  ignoreSilentSwitchMode: IgnoreSilentSwitchMode;
  playInBackground: boolean;
  playWhenInactive: boolean;
  disableAudioSessionManagement: boolean;
  readonly isPlaying: boolean;
  initialize(): Promise<void>;
  preload(): Promise<void>;
  play(): void;
  pause(): void;
  seekBy(time: number): void;
  seekTo(time: number): void;
  readonly selectedTrack?: TextTrack;
}

@Apple({ language: 'swift', implementation: { className: 'HybridVideoPlayerFactory' } })
@Android({ language: 'kotlin', implementation: { className: 'HybridVideoPlayerFactory' } })
export declare class VideoPlayerFactory extends HybridObject {
  constructor();
  createPlayer(source: VideoPlayerSource): VideoPlayer;
  setAudioSessionManagementDisabled(disabled: boolean): void;
}
