package com.twg.video.core.fragments

import android.content.res.Configuration
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.annotation.OptIn
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.media3.common.util.UnstableApi
import com.twg.video.core.VideoManager
import com.twg.video.view.VideoView
import java.util.UUID

@OptIn(UnstableApi::class)
class PictureInPictureHelperFragment() : Fragment() {
  private var videoView: VideoView? = null
  val id: String = UUID.randomUUID().toString()

  constructor(videoView: VideoView) : this() {
    this.videoView = videoView
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)

    if (videoView == null) {
      // The original view is gone after restoration. React Native will add a new helper
      // when it remounts the VideoView, so remove this orphaned fragment.
      Handler(Looper.getMainLooper()).post {
        if (isAdded) {
          parentFragmentManager.beginTransaction()
            .remove(this)
            .commitAllowingStateLoss()
        }
      }
    }
  }

  override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean) {
    super.onPictureInPictureModeChanged(isInPictureInPictureMode)

    val videoView = videoView ?: return

    if (isInPictureInPictureMode) {
      var currentPipVideo = VideoManager.getCurrentPictureInPictureVideo()
      
      if (currentPipVideo == null) {
        synchronized(VideoManager) {
          currentPipVideo = VideoManager.getCurrentPictureInPictureVideo()
          if (currentPipVideo == null) {
            if (videoView.hybridPlayer?.isPlaying == true) {
              val lastPlayed = VideoManager.getLastPlayedVideoView()
              val shouldDesignate = lastPlayed == null || lastPlayed.nitroId == videoView.nitroId

              if (shouldDesignate) {
                VideoManager.setCurrentPictureInPictureVideo(videoView)
                videoView.hybridPlayer?.movePlayerToVideoView(videoView)
                VideoManager.pauseOtherPlayers(videoView)
                currentPipVideo = videoView
              }
            } else {
              if (!VideoManager.isAnyVideoInPictureInPicture()) {
                val lastPlayed = VideoManager.getLastPlayedVideoView()
                val targetView = lastPlayed ?: videoView

                VideoManager.setCurrentPictureInPictureVideo(targetView)
                targetView.hybridPlayer?.movePlayerToVideoView(targetView)
                VideoManager.pauseOtherPlayers(targetView)
                currentPipVideo = targetView
              }
            }
          }
        }
      }
      
      if (currentPipVideo == videoView) {
        // Disable controls immediately when entering PiP - media session creates its own controls for PiP
        videoView.playerView.useController = false
        videoView.playerView.controllerAutoShow = false

        // If we're currently in fullscreen, exit it first to prevent parent conflicts
        if (videoView.isInFullscreen) {
          try {
            videoView.exitFullscreen()
            // Post hideRootContentViews to main thread to ensure it runs after exitFullscreen completes
            Handler(Looper.getMainLooper()).post {
              videoView.hideRootContentViews()
              videoView.isInPictureInPicture = true
            }
          } catch (e: Exception) {
            Log.w("ReactNativeVideo", "Failed to exit fullscreen before entering PiP for nitroId: ${videoView.nitroId}", e)
            videoView.hideRootContentViews()
            videoView.isInPictureInPicture = true
          }
        } else {
          // Now move the PlayerView to the root for PiP and hide content
          videoView.hideRootContentViews()
          videoView.isInPictureInPicture = true
        }
      }
    } else {
      if (videoView.isInPictureInPicture) {
        videoView.exitPictureInPicture()
      }

      // Expanding back to the app leaves the fragment STARTED/RESUMED; closing (X) stops and
      // finishes it (CREATED → DESTROYED). Pause whenever it is no longer started — the user
      // dismissed the window rather than expanding it.
      if (!lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) {
        videoView.hybridPlayer?.pause()
      }
    }
  }
}
