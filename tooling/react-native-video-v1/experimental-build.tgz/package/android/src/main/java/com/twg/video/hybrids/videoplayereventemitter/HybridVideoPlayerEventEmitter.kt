package com.margelo.nitro.video

import android.util.Log
import com.margelo.nitro.core.NullType
import com.margelo.nitro.core.Callback
import com.margelo.nitro.core.invoke
import java.util.UUID

data class ListenerPair(val id: UUID, val eventName: String, val callback: Any)

class HybridVideoPlayerEventEmitter : HybridVideoPlayerEventEmitterSpec() {
  private val lock = Any()

  var listeners: MutableList<ListenerPair> = mutableListOf()

  // MARK: - Private helpers
  private fun <T : Any> addListener(eventName: String, listener: T): ListenerSubscription {
    val id = UUID.randomUUID()
    synchronized(lock) {
      listeners.add(ListenerPair(id, eventName, listener))
    }
    return ListenerSubscription(Callback.native<() -> Unit> {
      synchronized(lock) {
        listeners.removeAll { it.id == id }
      }
    })
  }

  private inline fun <reified T> emitEvent(eventName: String, invokeCallback: (T) -> Unit) {
    val snapshot: List<ListenerPair> = synchronized(lock) {
      listeners.filter { it.eventName == eventName }.toList()
    }

    snapshot.forEach { pair ->
      try {
        @Suppress("UNCHECKED_CAST")
        val callback = pair.callback as? T ?: run {
          Log.d(TAG, "Invalid callback type for $eventName")
          return@forEach
        }
        invokeCallback(callback)
      } catch (t: Throwable) {
        Log.d(TAG, "Error calling $eventName listener", t)
      }
    }
  }


  // MARK: - Listener registration methods
  
  override fun addOnAudioBecomingNoisyListener(listener: Callback<() -> Unit>) =
    addListener("onAudioBecomingNoisy", listener)

  override fun addOnAudioFocusChangeListener(listener: Callback<(Boolean) -> Unit>) =
    addListener("onAudioFocusChange", listener)

  override fun addOnBandwidthUpdateListener(listener: Callback<(BandwidthData) -> Unit>) =
    addListener("onBandwidthUpdate", listener)

  override fun addOnBufferListener(listener: Callback<(Boolean) -> Unit>) =
    addListener("onBuffer", listener)

  override fun addOnControlsVisibleChangeListener(listener: Callback<(Boolean) -> Unit>) =
    addListener("onControlsVisibleChange", listener)

  override fun addOnEndListener(listener: Callback<() -> Unit>) =
    addListener("onEnd", listener)

  override fun addOnErrorListener(listener: Callback<(String) -> Unit>) =
    addListener("onError", listener)

  override fun addOnExternalPlaybackChangeListener(listener: Callback<(Boolean) -> Unit>) =
    addListener("onExternalPlaybackChange", listener)

  override fun addOnLoadListener(listener: Callback<(onLoadData) -> Unit>) =
    addListener("onLoad", listener)

  override fun addOnLoadStartListener(listener: Callback<(onLoadStartData) -> Unit>) =
    addListener("onLoadStart", listener)

  override fun addOnPlaybackStateChangeListener(listener: Callback<(onPlaybackStateChangeData) -> Unit>) =
    addListener("onPlaybackStateChange", listener)

  override fun addOnPlaybackRateChangeListener(listener: Callback<(Double) -> Unit>) =
    addListener("onPlaybackRateChange", listener)

  override fun addOnProgressListener(listener: Callback<(onProgressData) -> Unit>) =
    addListener("onProgress", listener)

  override fun addOnReadyToDisplayListener(listener: Callback<() -> Unit>) =
    addListener("onReadyToDisplay", listener)

  override fun addOnSeekListener(listener: Callback<(Double) -> Unit>) =
    addListener("onSeek", listener)

  override fun addOnStatusChangeListener(listener: Callback<(VideoPlayerStatus) -> Unit>) =
    addListener("onStatusChange", listener)

  override fun addOnTimedMetadataListener(listener: Callback<(TimedMetadata) -> Unit>) =
    addListener("onTimedMetadata", listener)

  override fun addOnTextTrackDataChangedListener(listener: Callback<(Array<String>) -> Unit>) =
    addListener("onTextTrackDataChanged", listener)

  override fun addOnTrackChangeListener(listener: Callback<(Variant_NullType_TextTrack) -> Unit>) =
    addListener("onTrackChange", listener)

  override fun addOnVolumeChangeListener(listener: Callback<(onVolumeChangeData) -> Unit>) =
    addListener("onVolumeChange", listener)

  override fun clearAllListeners() {
    synchronized(lock) {
      listeners.clear()
    }
  }

  // MARK: - Event emission methods

  fun onAudioBecomingNoisy() =
    emitEvent<Callback<() -> Unit>>("onAudioBecomingNoisy") { it() }

  fun onAudioFocusChange(hasFocus: Boolean) =
    emitEvent<Callback<(Boolean) -> Unit>>("onAudioFocusChange") { it(hasFocus) }

  fun onBandwidthUpdate(data: BandwidthData) =
    emitEvent<Callback<(BandwidthData) -> Unit>>("onBandwidthUpdate") { it(data) }

  fun onBuffer(isBuffering: Boolean) =
    emitEvent<Callback<(Boolean) -> Unit>>("onBuffer") { it(isBuffering) }

  fun onControlsVisibleChange(isVisible: Boolean) =
    emitEvent<Callback<(Boolean) -> Unit>>("onControlsVisibleChange") { it(isVisible) }

  fun onEnd() =
    emitEvent<Callback<() -> Unit>>("onEnd") { it() }

  fun onError(error: String) =
    emitEvent<Callback<(String) -> Unit>>("onError") { it(error) }

  fun onExternalPlaybackChange(isExternalPlayback: Boolean) =
    emitEvent<Callback<(Boolean) -> Unit>>("onExternalPlaybackChange") { it(isExternalPlayback) }

  fun onLoad(data: onLoadData) =
    emitEvent<Callback<(onLoadData) -> Unit>>("onLoad") { it(data) }

  fun onLoadStart(data: onLoadStartData) =
    emitEvent<Callback<(onLoadStartData) -> Unit>>("onLoadStart") { it(data) }

  fun onPlaybackStateChange(data: onPlaybackStateChangeData) =
    emitEvent<Callback<(onPlaybackStateChangeData) -> Unit>>("onPlaybackStateChange") { it(data) }

  fun onPlaybackRateChange(rate: Double) =
    emitEvent<Callback<(Double) -> Unit>>("onPlaybackRateChange") { it(rate) }

  fun onProgress(data: onProgressData) =
    emitEvent<Callback<(onProgressData) -> Unit>>("onProgress") { it(data) }

  fun onReadyToDisplay() =
    emitEvent<Callback<() -> Unit>>("onReadyToDisplay") { it() }

  fun onSeek(position: Double) =
    emitEvent<Callback<(Double) -> Unit>>("onSeek") { it(position) }

  fun onTimedMetadata(metadata: TimedMetadata) =
    emitEvent<Callback<(TimedMetadata) -> Unit>>("onTimedMetadata") { it(metadata) }

  fun onTextTrackDataChanged(tracks: Array<String>) =
    emitEvent<Callback<(Array<String>) -> Unit>>("onTextTrackDataChanged") { it(tracks) }

  fun onTrackChange(track: TextTrack?) {
    val param = if (track == null) {
      Variant_NullType_TextTrack.create(NullType.NULL)
    } else {
      Variant_NullType_TextTrack.create(track)
    }
    emitEvent<Callback<(Variant_NullType_TextTrack) -> Unit>>("onTrackChange") { it(param) }
  }

  fun onVolumeChange(data: onVolumeChangeData) =
    emitEvent<Callback<(onVolumeChangeData) -> Unit>>("onVolumeChange") { it(data) }

  fun onStatusChange(status: VideoPlayerStatus) =
    emitEvent<Callback<(VideoPlayerStatus) -> Unit>>("onStatusChange") { it(status) }

  companion object : HybridVideoPlayerEventEmitterSpec.Companion {
    const val TAG = "HybridVideoPlayerEventEmitter"
  }
}
