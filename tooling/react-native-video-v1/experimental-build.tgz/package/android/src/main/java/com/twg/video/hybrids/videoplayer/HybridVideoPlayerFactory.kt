package com.margelo.nitro.video

import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import com.facebook.proguard.annotations.DoNotStrip

@DoNotStrip
class HybridVideoPlayerFactory(): HybridVideoPlayerFactorySpec() {
  companion object : HybridVideoPlayerFactorySpec.Companion {
    override fun constructor(): HybridVideoPlayerFactory = HybridVideoPlayerFactory()
  }

  @OptIn(UnstableApi::class)
  override fun createPlayer(source: HybridVideoPlayerSourceSpec): HybridVideoPlayerSpec {
    return HybridVideoPlayer(source as HybridVideoPlayerSource)
  }

  override fun setAudioSessionManagementDisabled(disabled: Boolean) {
    // No-op on Android - audio session management is iOS-specific
  }

  override val memorySize: Long
    get() = 0
}
