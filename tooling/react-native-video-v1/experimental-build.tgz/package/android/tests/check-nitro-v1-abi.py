#!/usr/bin/env python3
"""Source contract checks, not a substitute for an Android compile/device test."""
from pathlib import Path
import re
import unittest

ANDROID = Path(__file__).resolve().parents[1]
GENERATED = ANDROID.parent / 'nitrogen/generated/android'
KOTLIN = GENERATED / 'kotlin/com/margelo/nitro/video'
SOURCES = ANDROID / 'src/main/java/com/twg/video/hybrids'


def parameters(line):
    # All generated methods use single-line signatures. Locate the method's
    # matching close paren, rather than the nested callback function's parens.
    start = line.index('(')
    depth = 0
    for end in range(start, len(line)):
        depth += (line[end] == '(') - (line[end] == ')')
        if depth == 0:
            args = line[start + 1:end]
            args = re.sub(r'\b\w+\s*:\s*', '', args)
            return re.sub(r'\s+', '', args)
    raise AssertionError(f'Unbalanced signature: {line}')


class NitroV1Contract(unittest.TestCase):
    def test_all_generated_method_parameters_match_implementations(self):
        count = 0
        for spec in KOTLIN.glob('Hybrid*Spec.kt'):
            name = spec.stem.removesuffix('Spec')
            matches = list(SOURCES.rglob(f'{name}.kt'))
            self.assertEqual(len(matches), 1, name)
            implementation = matches[0].read_text()
            for signature in spec.read_text().splitlines():
                method = re.search(r'abstract fun (\w+)\(', signature)
                if not method:
                    continue
                candidates = [line for line in implementation.splitlines()
                              if f'override fun {method[1]}(' in line]
                self.assertEqual(len(candidates), 1, f'{name}.{method[1]}')
                self.assertEqual(parameters(signature), parameters(candidates[0]),
                                 f'{name}.{method[1]}')
                count += 1
        self.assertGreater(count, 40)

    def test_all_implementations_expose_v1_companions(self):
        for spec in KOTLIN.glob('Hybrid*Spec.kt'):
            name = spec.stem.removesuffix('Spec')
            source = next(SOURCES.rglob(f'{name}.kt')).read_text()
            self.assertIn(f'companion object : {spec.stem}.Companion', source)

    def test_callback_subscriptions_use_native_wrapper(self):
        for name in ['HybridVideoPlayerEventEmitter', 'HybridVideoViewViewManager']:
            source = next(SOURCES.rglob(f'{name}.kt')).read_text()
            self.assertIn('ListenerSubscription(Callback.native<() -> Unit>', source)
            self.assertNotIn('emitEvent<(', source)
            self.assertIn('import com.margelo.nitro.core.invoke', source)

    def test_source_variant_uses_source_first(self):
        variant = (KOTLIN / 'Variant_HybridVideoPlayerSourceSpec_NullType.kt').read_text()
        self.assertRegex(variant, r'data class First\([^\n]*value: HybridVideoPlayerSourceSpec')
        source = next(SOURCES.rglob('HybridVideoPlayer.kt')).read_text()
        self.assertIn('val source = source.asFirstOrNull()', source)

    def test_jni_entry_matches_generated_registration(self):
        source = (ANDROID / 'src/main/cpp/cpp-adapter.cpp').read_text()
        self.assertIn('facebook::jni::initialize(vm', source)
        self.assertIn('margelo::nitro::video::registerAllNatives()', source)
        header = GENERATED / 'include/ReactNativeVideo/private/ReactNativeVideoOnLoad.hpp'
        self.assertTrue(header.is_file())
        self.assertIn('void registerAllNatives();', header.read_text())


if __name__ == '__main__':
    unittest.main()
